<?php
/**
 * TradingAgents PHP 8.4 — Multi-Agent State Graph & Progressive Step Orchestrator
 *
 * Re-implements the complete TauricResearch/TradingAgents LangGraph workflow in pure PHP 8.4 + MySQL:
 *
 * Stage 1 (Analyst Team — Quick-Think LLM):
 *   - Market / Technical Analyst (`market_analyst`)
 *   - Social / Sentiment Analyst (`sentiment_analyst` -> structured SentimentReport)
 *   - News & Macro Analyst (`news_analyst` -> Yahoo/Google News, FRED, Polymarket)
 *   - Fundamentals Analyst (`fundamentals_analyst` -> SEC EDGAR XBRL, Alpha Vantage, Yahoo)
 *
 * Stage 2 (Research Debate Team — Quick-Think Debaters + Deep-Think Research Manager):
 *   - Bullish Researcher (`bull_round_N`) vs. Bearish Researcher (`bear_round_N`) for N debate rounds
 *   - Research Manager (`research_manager` -> structured ResearchPlan: Buy/Overweight/Hold/Underweight/Sell)
 *
 * Stage 3 (Trader Desk — Quick-Think LLM):
 *   - Trader (`trader` -> structured TraderProposal: Buy/Hold/Sell, absolute Entry Price, Stop Loss, Sizing)
 *
 * Stage 4 (Risk Management Committee — Quick-Think LLM):
 *   - Aggressive Risk Analyst (`risk_aggressive_N`)
 *   - Conservative Risk Analyst (`risk_conservative_N`)
 *   - Neutral Risk Analyst (`risk_neutral_N`)
 *
 * Stage 5 (Portfolio Manager — Deep-Think LLM):
 *   - Portfolio Manager (`portfolio_manager` -> structured PortfolioDecision: 5-tier rating, Executive Summary,
 *     Investment Thesis, Price Target, Time Horizon, plus Memory Log recording).
 *
 * Designed for Shared Hosting: Each step executes independently in `executeNextStep($analysisId)`
 * via progressive AJAX or Cron Queue so no HTTP request ever exceeds shared hosting time limits.
 */

declare(strict_types=1);

namespace TradingAgents;

use RuntimeException;
use Throwable;

final class AgentOrchestrator
{
    /**
     * Creates a new multi-agent analysis run and populates its step-by-step execution queue.
     */
    public static function createAnalysis(
        int $userId,
        string $ticker,
        string $tradeDate,
        array $selectedAnalysts = ['market', 'social', 'news', 'fundamentals'],
        int $maxDebateRounds = 1,
        int $maxRiskRounds = 1,
        ?string $quickProvider = null,
        ?string $quickModel = null,
        ?string $deepProvider = null,
        ?string $deepModel = null,
        string $outputLanguage = 'English'
    ): array {
        $cleanTicker = Security::cleanTicker($ticker);
        if ($cleanTicker === '') {
            throw new RuntimeException('Please enter a valid stock or crypto ticker symbol (e.g. NVDA, AAPL, MSFT, BTC-USD).');
        }

        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tradeDate) || $tradeDate > gmdate('Y-m-d')) {
            $tradeDate = gmdate('Y-m-d');
        }

        $validAnalysts = array_values(array_intersect($selectedAnalysts, ['market', 'social', 'news', 'fundamentals']));
        if (empty($validAnalysts)) {
            $validAnalysts = ['market', 'social', 'news', 'fundamentals'];
        }

        $maxDebateRounds = max(1, min(3, $maxDebateRounds));
        $maxRiskRounds   = max(1, min(3, $maxRiskRounds));

        $quickProvider = $quickProvider ?: (string)Database::getSetting('QuickThinkProvider', 'openrouter');
        $quickModel    = $quickModel    ?: (string)Database::getSetting('QuickThinkModel', 'openrouter/free');
        $deepProvider  = $deepProvider  ?: (string)Database::getSetting('DeepThinkProvider', 'openrouter');
        $deepModel     = $deepModel     ?: (string)Database::getSetting('DeepThinkModel', 'openrouter/free');

        $uuid = self::uuidV4();

        // Build caller portfolio context & past memory context
        $portfolioContext = self::buildPortfolioContext($userId, $cleanTicker);
        $pastMemoryContext = self::buildPastMemoryContext($cleanTicker, $tradeDate);

        $analysisId = Database::insert(
            "INSERT INTO `analyses`
             (`run_uuid`, `user_id`, `ticker`, `trade_date`, `status`, `current_step`, `progress_pct`,
              `selected_analysts`, `max_debate_rounds`, `max_risk_rounds`,
              `quick_think_provider`, `quick_think_model`, `deep_think_provider`, `deep_think_model`,
              `output_language`, `portfolio_context`, `past_memory_context`, `started_at`)
             VALUES
             (:uuid, :uid, :ticker, :tdate, 'queued', 'queued', 0,
              :analysts, :debate, :risk,
              :qp, :qm, :dp, :dm,
              :lang, :pctx, :mctx, NOW())",
            [
                ':uuid'     => $uuid,
                ':uid'      => $userId,
                ':ticker'   => $cleanTicker,
                ':tdate'    => $tradeDate,
                ':analysts' => implode(',', $validAnalysts),
                ':debate'   => $maxDebateRounds,
                ':risk'     => $maxRiskRounds,
                ':qp'       => $quickProvider,
                ':qm'       => $quickModel,
                ':dp'       => $deepProvider,
                ':dm'       => $deepModel,
                ':lang'     => $outputLanguage,
                ':pctx'     => $portfolioContext,
                ':mctx'     => $pastMemoryContext,
            ]
        );

        // Guaranteed fallback lookup by run_uuid so fk_queue_analysis can never fail with 1452
        if ($analysisId <= 0) {
            $analysisId = (int)Database::fetchColumn(
                "SELECT `id` FROM `analyses` WHERE `run_uuid` = :u LIMIT 1",
                [':u' => $uuid]
            );
        }
        if ($analysisId <= 0) {
            throw new RuntimeException('Failed to retrieve newly created analysis ID from MySQL.');
        }

        // Build ordered step queue
        $steps = [];
        $analystLabels = [
            'market'       => ['market_analyst', 'Technical / Market Analyst (OHLCV, SMA, EMA, RSI, MACD, Bollinger, ATR, VWMA)'],
            'social'       => ['sentiment_analyst', 'Sentiment Analyst (StockTwits Cashtags, Reddit r/wallstreetbets+stocks, News)'],
            'news'         => ['news_analyst', 'News & Macro Analyst (Company News, Global Headlines, FRED, Polymarket Odds)'],
            'fundamentals' => ['fundamentals_analyst', 'Fundamentals Analyst (SEC EDGAR XBRL Filings, Valuation & Ratios)'],
        ];

        foreach ($validAnalysts as $aKey) {
            if (isset($analystLabels[$aKey])) {
                $steps[] = $analystLabels[$aKey];
            }
        }

        // Research Bull vs Bear Debate Rounds
        for ($r = 1; $r <= $maxDebateRounds; $r++) {
            $steps[] = ["bull_round_{$r}", "Bullish Researcher — Debate Round #{$r}"];
            $steps[] = ["bear_round_{$r}", "Bearish Researcher — Debate Round #{$r}"];
        }

        // Research Manager
        $steps[] = ['research_manager', 'Research Manager — Investment Plan Synthesis'];

        // Trader
        $steps[] = ['trader', 'Trader Agent — Concrete Entry, Stop-Loss & Sizing Proposal'];

        // Risk Management Team Debate Rounds
        for ($r = 1; $r <= $maxRiskRounds; $r++) {
            $steps[] = ["risk_aggressive_{$r}", "Aggressive Risk Analyst — Evaluation Round #{$r}"];
            $steps[] = ["risk_conservative_{$r}", "Conservative Risk Analyst — Evaluation Round #{$r}"];
            $steps[] = ["risk_neutral_{$r}", "Neutral Risk Analyst — Evaluation Round #{$r}"];
        }

        // Final Portfolio Manager Decision
        $steps[] = ['portfolio_manager', 'Portfolio Manager — Final Executive Trading Decision'];

        $order = 1;
        foreach ($steps as [$sKey, $sLabel]) {
            Database::query(
                "INSERT INTO `analysis_queue` (`analysis_id`, `step_order`, `step_key`, `step_label`, `status`)
                 VALUES (:aid, :ord, :skey, :slbl, 'pending')",
                [
                    ':aid'  => $analysisId,
                    ':ord'  => $order++,
                    ':skey' => $sKey,
                    ':slbl' => $sLabel,
                ]
            );
        }

        Logger::log('INFO', 'agent', "Created multi-agent analysis #{$analysisId} ({$cleanTicker} as of {$tradeDate}) with " . count($steps) . " queued steps.", $userId);

        return [
            'analysis_id' => $analysisId,
            'run_uuid'    => $uuid,
            'ticker'      => $cleanTicker,
            'trade_date'  => $tradeDate,
            'total_steps' => count($steps),
        ];
    }

    /**
     * Executes the next pending step for `$analysisId`.
     * Safe for progressive AJAX polling and background Cron jobs.
     */
    public static function executeNextStep(int $analysisId): array
    {
        @set_time_limit((int)Bootstrap::config('hosting.step_time_limit', 55));

        $analysis = Database::fetchOne("SELECT * FROM `analyses` WHERE `id` = :id LIMIT 1", [':id' => $analysisId]);
        if (!$analysis) {
            return ['ok' => false, 'error' => 'Analysis record not found.'];
        }

        if ($analysis['status'] === 'completed') {
            return [
                'ok'           => true,
                'status'       => 'completed',
                'progress_pct' => 100,
                'analysis'     => $analysis,
                'reports'      => self::getReports($analysisId),
            ];
        }

        // Fetch next pending queue item (or recover stale 'processing' item older than 90 sec)
        $nextItem = Database::fetchOne(
            "SELECT * FROM `analysis_queue`
             WHERE `analysis_id` = :aid
               AND (`status` = 'pending' OR (`status` = 'processing' AND `locked_at` < DATE_SUB(NOW(), INTERVAL 90 SECOND)))
             ORDER BY `step_order` ASC
             LIMIT 1",
            [':aid' => $analysisId]
        );

        if (!$nextItem) {
            Database::query(
                "UPDATE `analyses` SET `status` = 'completed', `progress_pct` = 100, `current_step` = 'completed', `completed_at` = NOW() WHERE `id` = :id",
                [':id' => $analysisId]
            );
            $updated = Database::fetchOne("SELECT * FROM `analyses` WHERE `id` = :id", [':id' => $analysisId]);
            return [
                'ok'           => true,
                'status'       => 'completed',
                'progress_pct' => 100,
                'analysis'     => $updated,
                'reports'      => self::getReports($analysisId),
            ];
        }

        $queueId   = (int)$nextItem['id'];
        $stepKey   = (string)$nextItem['step_key'];
        $stepLabel = (string)$nextItem['step_label'];

        // Mark queue item and analysis as running
        Database::query(
            "UPDATE `analysis_queue` SET `status` = 'processing', `attempts` = `attempts` + 1, `locked_at` = NOW() WHERE `id` = :qid",
            [':qid' => $queueId]
        );
        Database::query(
            "UPDATE `analyses` SET `status` = 'running', `current_step` = :step WHERE `id` = :aid",
            [':step' => $stepLabel, ':aid' => $analysisId]
        );

        try {
            // Ensure instrument context is resolved on first step
            if (empty($analysis['instrument_context'])) {
                $identity = MarketDataService::resolveInstrumentContext((string)$analysis['ticker'], (string)$analysis['trade_date']);
                Database::query(
                    "UPDATE `analyses`
                     SET `company_name` = :cname, `asset_type` = :atype, `currency` = :curr,
                         `market_price_at_analysis` = :price, `instrument_context` = :ictx
                     WHERE `id` = :aid",
                    [
                        ':cname' => $identity['company_name'],
                        ':atype' => $identity['asset_type'],
                        ':curr'  => $identity['currency'],
                        ':price' => $identity['latest_price'],
                        ':ictx'  => $identity['context_text'],
                        ':aid'   => $analysisId,
                    ]
                );
                $analysis = Database::fetchOne("SELECT * FROM `analyses` WHERE `id` = :id", [':id' => $analysisId]);
            }

            // Dispatch step execution
            $stepResult = self::runStepLogic($analysis, $stepKey);

            // Save agent report
            Database::query(
                "INSERT INTO `agent_reports`
                 (`analysis_id`, `step_key`, `agent_role`, `stage_group`, `round_number`,
                  `provider_used`, `model_used`, `report_markdown`, `structured_json`,
                  `tokens_used`, `latency_ms`, `status`)
                 VALUES
                 (:aid, :skey, :role, :grp, :rnd, :prov, :mod, :md, :sjson, :tok, :lat, 'completed')
                 ON DUPLICATE KEY UPDATE
                  `provider_used` = VALUES(`provider_used`),
                  `model_used` = VALUES(`model_used`),
                  `report_markdown` = VALUES(`report_markdown`),
                  `structured_json` = VALUES(`structured_json`),
                  `tokens_used` = VALUES(`tokens_used`),
                  `latency_ms` = VALUES(`latency_ms`),
                  `status` = 'completed'",
                [
                    ':aid'   => $analysisId,
                    ':skey'  => $stepKey,
                    ':role'  => $stepResult['agent_role'],
                    ':grp'   => $stepResult['stage_group'],
                    ':rnd'   => $stepResult['round_number'] ?? 1,
                    ':prov'  => $stepResult['provider'] ?? null,
                    ':mod'   => $stepResult['model'] ?? null,
                    ':md'    => $stepResult['markdown'],
                    ':sjson' => isset($stepResult['structured']) ? json_encode($stepResult['structured'], JSON_UNESCAPED_UNICODE) : null,
                    ':tok'   => (int)($stepResult['tokens'] ?? 0),
                    ':lat'   => (int)($stepResult['latency_ms'] ?? 0),
                ]
            );

            // Mark queue item completed
            Database::query(
                "UPDATE `analysis_queue` SET `status` = 'completed', `completed_at` = NOW(), `error_text` = NULL WHERE `id` = :qid",
                [':qid' => $queueId]
            );

            // Update progress percentage & aggregate token/time counters
            $totalSteps = (int)Database::fetchColumn("SELECT COUNT(*) FROM `analysis_queue` WHERE `analysis_id` = ?", [$analysisId]);
            $doneSteps  = (int)Database::fetchColumn("SELECT COUNT(*) FROM `analysis_queue` WHERE `analysis_id` = ? AND `status` = 'completed'", [$analysisId]);
            $progressPct = $totalSteps > 0 ? (int) min(100, round(($doneSteps / $totalSteps) * 100)) : 100;
            $isFinished  = ($doneSteps >= $totalSteps);

            Database::query(
                "UPDATE `analyses`
                 SET `progress_pct` = :pct,
                     `status` = :st,
                     `current_step` = :cstep,
                     `total_llm_calls` = `total_llm_calls` + 1,
                     `total_tokens_used` = `total_tokens_used` + :tok,
                     `execution_time_ms` = `execution_time_ms` + :lat,
                     `completed_at` = IF(:isfin = 1, NOW(), `completed_at`)
                 WHERE `id` = :aid",
                [
                    ':pct'   => $progressPct,
                    ':st'    => $isFinished ? 'completed' : 'running',
                    ':cstep' => $isFinished ? 'completed' : $stepLabel,
                    ':tok'   => (int)($stepResult['tokens'] ?? 0),
                    ':lat'   => (int)($stepResult['latency_ms'] ?? 0),
                    ':isfin' => $isFinished ? 1 : 0,
                    ':aid'   => $analysisId,
                ]
            );

            $updatedAnalysis = Database::fetchOne("SELECT * FROM `analyses` WHERE `id` = :id", [':id' => $analysisId]);

            return [
                'ok'             => true,
                'status'         => $updatedAnalysis['status'],
                'completed_step' => $stepKey,
                'step_label'     => $stepLabel,
                'progress_pct'   => (int)$updatedAnalysis['progress_pct'],
                'done_steps'     => $doneSteps,
                'total_steps'    => $totalSteps,
                'analysis'       => $updatedAnalysis,
                'reports'        => self::getReports($analysisId),
                'queue'          => self::getQueue($analysisId),
            ];
        } catch (Throwable $e) {
            $errMsg = Logger::scrub($e->getMessage());
            Database::query(
                "UPDATE `analysis_queue` SET `status` = 'failed', `error_text` = :err WHERE `id` = :qid",
                [':err' => $errMsg, ':qid' => $queueId]
            );
            Database::query(
                "UPDATE `analyses` SET `status` = 'failed', `error_message` = :err WHERE `id` = :aid",
                [':err' => $errMsg, ':aid' => $analysisId]
            );
            Logger::log('ERROR', 'agent', "Analysis #{$analysisId} failed at step {$stepKey}: {$errMsg}", (int)$analysis['user_id']);

            return [
                'ok'         => false,
                'status'     => 'failed',
                'failed_step'=> $stepKey,
                'error'      => $errMsg,
                'analysis'   => Database::fetchOne("SELECT * FROM `analyses` WHERE `id` = :id", [':id' => $analysisId]),
                'reports'    => self::getReports($analysisId),
                'queue'      => self::getQueue($analysisId),
            ];
        }
    }

    /**
     * Dispatches the exact prompt and structured schema logic for each TradingAgents node.
     */
    private static function runStepLogic(array $analysis, string $stepKey): array
    {
        $analysisId = (int)$analysis['id'];
        $ticker     = (string)$analysis['ticker'];
        $tradeDate  = (string)$analysis['trade_date'];
        $instCtx    = (string)($analysis['instrument_context'] ?? '');
        $portCtx    = (string)($analysis['portfolio_context'] ?? '');
        $pastCtx    = (string)($analysis['past_memory_context'] ?? '');
        $lang       = (string)($analysis['output_language'] ?? 'English');
        $langInstr  = ($lang !== '' && strtolower($lang) !== 'english')
            ? "\n\nIMPORTANT: Write your entire report and analysis in {$lang}."
            : '';

        $quickProv  = (string)$analysis['quick_think_provider'];
        $quickMod   = (string)$analysis['quick_think_model'];
        $deepProv   = (string)$analysis['deep_think_provider'];
        $deepMod    = (string)$analysis['deep_think_model'];

        $existingReports = self::getReportsByKey($analysisId);

        // =====================================================================
        // 1. MARKET / TECHNICAL ANALYST (`market_analyst.py`)
        // =====================================================================
        if ($stepKey === 'market_analyst') {
            $ohlcv = MarketDataService::getOhlcvAndQuote($ticker, $tradeDate);
            $snapshotMd = $ohlcv['summary_markdown'] ?? 'No market data available.';

            $messages = [
                [
                    'role' => 'system',
                    'content' => "You are a trading assistant and Senior Technical Market Analyst tasked with analyzing financial markets for {$ticker} as of {$tradeDate}. {$instCtx}\n\n"
                        . "Your role is to analyze the complementary technical indicators computed from the verified OHLCV data below:\n"
                        . "- Moving Averages: close_10_ema (10 EMA short-term momentum), close_50_sma (50 SMA medium-term trend), close_200_sma (200 SMA long-term benchmark)\n"
                        . "- MACD Suite: macd (12,26 EMA diff), macds (9 EMA signal), macdh (MACD histogram)\n"
                        . "- Momentum: rsi (14-period Wilder's RSI)\n"
                        . "- Volatility: boll (20 SMA middle), boll_ub (+2σ upper band), boll_lb (-2σ lower band), atr (14-period Wilder's ATR)\n"
                        . "- Volume: vwma (20-period Volume-Weighted Moving Average)\n\n"
                        . "Treat the Verified Market Snapshot below as the exact source of truth for all OHLCV prices, support/resistance levels, and indicator values. Write a detailed, nuanced technical report analyzing trend structure, momentum divergences, volatility regime, key support/resistance zones, and ATR-based stop distances. Append a clean Markdown summary table at the end of the report.{$langInstr}",
                ],
                [
                    'role' => 'user',
                    'content' => "Here is the verified OHLCV and Technical Indicator dataset for {$ticker} as of {$tradeDate}:\n\n{$snapshotMd}\n\nWrite the comprehensive Technical & Market Analyst Report now.",
                ],
            ];

            $llmRes = LLMClient::chat($messages, 'quick', $quickProv, $quickMod);
            return [
                'agent_role'  => 'Market / Technical Analyst',
                'stage_group' => 'analyst_team',
                'markdown'    => $llmRes['content'],
                'provider'    => $llmRes['provider'],
                'model'       => $llmRes['model'],
                'tokens'      => $llmRes['tokens'],
                'latency_ms'  => $llmRes['latency_ms'],
            ];
        }

        // =====================================================================
        // 2. SENTIMENT ANALYST (`sentiment_analyst.py` + `SentimentReport` schema)
        // =====================================================================
        if ($stepKey === 'sentiment_analyst') {
            $newsBundle   = MarketDataService::getNewsAndMacroBundle($ticker, $tradeDate);
            $socialBundle = MarketDataService::getSocialSentimentBundle($ticker, $tradeDate);

            $messages = [
                [
                    'role' => 'system',
                    'content' => "You are a financial market Sentiment Analyst. Your task is to produce a comprehensive sentiment report for {$ticker} as of {$tradeDate}, drawing on three real pre-fetched data sources: (1) Yahoo/Google News Headlines, (2) StockTwits retail cashtag stream with Bullish/Bearish user tags, and (3) Reddit community discussions (r/wallstreetbets, r/stocks, r/investing).\n\n"
                        . "{$instCtx}\n\n"
                        . "Return a valid JSON object with these exact keys:\n"
                        . "{\n"
                        . "  \"overall_band\": \"Bullish\" | \"Mildly Bullish\" | \"Neutral\" | \"Mixed\" | \"Mildly Bearish\" | \"Bearish\",\n"
                        . "  \"overall_score\": number between 0.0 and 10.0 (5.0 = neutral),\n"
                        . "  \"confidence\": \"low\" | \"medium\" | \"high\",\n"
                        . "  \"narrative\": \"Detailed markdown report covering: (1) source-by-source breakdown, (2) cross-source divergences, (3) dominant narrative themes, (4) catalysts and risks, and (5) a Markdown summary table of sentiment signals.\"\n"
                        . "}{$langInstr}",
                ],
                [
                    'role' => 'user',
                    'content' => "### 1. News Headlines (Past 7 Days)\n{$newsBundle['ticker_news']}\n\n"
                        . "### 2. StockTwits Retail Stream\n{$socialBundle['stocktwits']}\n\n"
                        . "### 3. Reddit Finance Communities\n{$socialBundle['reddit']}\n\n"
                        . "Respond with the JSON object containing `overall_band`, `overall_score`, `confidence`, and `narrative`.",
                ],
            ];

            $llmRes = LLMClient::chatStructured($messages, ['overall_band', 'overall_score', 'confidence', 'narrative'], 'quick', $quickProv, $quickMod);
            $struct = $llmRes['structured'];

            if (is_array($struct) && !empty($struct['narrative'])) {
                $band  = (string)($struct['overall_band'] ?? 'Neutral');
                $score = round((float)($struct['overall_score'] ?? 5.0), 1);
                $conf  = ucfirst(strtolower((string)($struct['confidence'] ?? 'medium')));
                $md    = "**Overall Sentiment:** **{$band}** (Score: {$score}/10)\n**Confidence:** {$conf}\n\n" . $struct['narrative'];

                Database::query(
                    "UPDATE `analyses` SET `sentiment_band` = :b, `sentiment_score` = :s, `sentiment_confidence` = :c WHERE `id` = :id",
                    [':b' => $band, ':s' => $score, ':c' => strtolower($conf), ':id' => $analysisId]
                );
            } else {
                $md = $llmRes['content'];
            }

            return [
                'agent_role'  => 'Social & Sentiment Analyst',
                'stage_group' => 'analyst_team',
                'markdown'    => $md,
                'structured'  => $struct,
                'provider'    => $llmRes['provider'],
                'model'       => $llmRes['model'],
                'tokens'      => $llmRes['tokens'],
                'latency_ms'  => $llmRes['latency_ms'],
            ];
        }

        // =====================================================================
        // 3. NEWS & MACRO ANALYST (`news_analyst.py`)
        // =====================================================================
        if ($stepKey === 'news_analyst') {
            $newsBundle = MarketDataService::getNewsAndMacroBundle($ticker, $tradeDate);

            $messages = [
                [
                    'role' => 'system',
                    'content' => "You are a News & Macroeconomic Researcher tasked with analyzing recent company news, global macroeconomic developments, FRED economic indicators, and Polymarket prediction market probabilities as of {$tradeDate}.\n"
                        . "{$instCtx}\n\n"
                        . "Write a comprehensive, evidence-backed report examining company-specific catalysts, sector headwinds/tailwinds, central bank policy, inflation/yield curve context, and forward-looking market-implied probabilities. Append a well-structured Markdown summary table at the end of the report.{$langInstr}",
                ],
                [
                    'role' => 'user',
                    'content' => "### Company News Headlines ({$ticker})\n{$newsBundle['ticker_news']}\n\n"
                        . "### Global & Macroeconomic Headlines\n{$newsBundle['macro_news']}\n\n"
                        . "### FRED Macroeconomic Indicators\n{$newsBundle['fred_macro']}\n\n"
                        . "### Polymarket Forward Event Implied Probabilities\n{$newsBundle['polymarket']}\n\n"
                        . "Produce the comprehensive News & Macroeconomic Analyst Report now.",
                ],
            ];

            $llmRes = LLMClient::chat($messages, 'quick', $quickProv, $quickMod);
            return [
                'agent_role'  => 'News & Macro Analyst',
                'stage_group' => 'analyst_team',
                'markdown'    => $llmRes['content'],
                'provider'    => $llmRes['provider'],
                'model'       => $llmRes['model'],
                'tokens'      => $llmRes['tokens'],
                'latency_ms'  => $llmRes['latency_ms'],
            ];
        }

        // =====================================================================
        // 4. FUNDAMENTALS ANALYST (`fundamentals_analyst.py`)
        // =====================================================================
        if ($stepKey === 'fundamentals_analyst') {
            $fundData = MarketDataService::getFundamentalsReportData($ticker, $tradeDate);

            $messages = [
                [
                    'role' => 'system',
                    'content' => "You are a Senior Equity Fundamentals Analyst tasked with analyzing official financial statements (SEC EDGAR XBRL Balance Sheet, Income Statement, Cash Flow), valuation multiples, profitability margins, and capital structure for {$ticker} as of {$tradeDate}.\n"
                        . "{$instCtx}\n\n"
                        . "Write a comprehensive fundamental analysis report with concrete numbers, growth/margin evaluation, balance sheet health, cash flow generation, and valuation insights to inform traders. Append an organized Markdown summary table at the end of the report.{$langInstr}",
                ],
                [
                    'role' => 'user',
                    'content' => "Here is the verified Fundamental & SEC EDGAR dataset for {$ticker} as of {$tradeDate}:\n\n{$fundData}\n\nWrite the comprehensive Fundamentals Analyst Report now.",
                ],
            ];

            $llmRes = LLMClient::chat($messages, 'quick', $quickProv, $quickMod);
            return [
                'agent_role'  => 'Fundamentals Analyst',
                'stage_group' => 'analyst_team',
                'markdown'    => $llmRes['content'],
                'provider'    => $llmRes['provider'],
                'model'       => $llmRes['model'],
                'tokens'      => $llmRes['tokens'],
                'latency_ms'  => $llmRes['latency_ms'],
            ];
        }

        // Gather all completed analyst reports for downstream Debate, Trader, Risk, and PM agents
        $marketRep = $existingReports['market_analyst']['report_markdown'] ?? '(Market report not selected)';
        $sentRep   = $existingReports['sentiment_analyst']['report_markdown'] ?? '(Sentiment report not selected)';
        $newsRep   = $existingReports['news_analyst']['report_markdown'] ?? '(News report not selected)';
        $fundRep   = $existingReports['fundamentals_analyst']['report_markdown'] ?? '(Fundamentals report not selected)';

        // =====================================================================
        // 5. BULLISH RESEARCHER (`bull_researcher.py`)
        // =====================================================================
        if (preg_match('/^bull_round_(\d+)$/', $stepKey, $m)) {
            $round = (int)$m[1];
            $debateHistory = self::buildDebateTranscript($existingReports, 'research_debate');
            $lastBearArg   = ($round > 1 && isset($existingReports['bear_round_' . ($round - 1)]))
                ? $existingReports['bear_round_' . ($round - 1)]['report_markdown']
                : '(Opening argument — no prior bear argument yet)';

            $messages = [
                [
                    'role' => 'system',
                    'content' => "You are a Bull Analyst advocating for investing in {$ticker}. Your task is to build a strong, evidence-based case emphasizing growth potential, competitive advantages, and positive market/technical/fundamental indicators. Leverage the provided research and data to address concerns and counter bearish arguments effectively.\n"
                        . "Key points to focus on:\n"
                        . "- Growth Potential: Market opportunities, revenue/earnings trajectory, and catalysts.\n"
                        . "- Competitive Advantages: Moat, product leadership, and institutional positioning.\n"
                        . "- Positive Indicators: Technical trend structure, valuation support, and positive news/sentiment.\n"
                        . "- Bear Counterpoints: Directly refute the bear analyst's claims with specific evidence.\n"
                        . "Present your argument in an engaging, conversational debate style.{$langInstr}",
                ],
                [
                    'role' => 'user',
                    'content' => "{$instCtx}\n\n"
                        . "### Market / Technical Report\n{$marketRep}\n\n"
                        . "### Social Sentiment Report\n{$sentRep}\n\n"
                        . "### News & Macro Report\n{$newsRep}\n\n"
                        . "### Fundamentals Report\n{$fundRep}\n\n"
                        . "### Debate Transcript So Far\n" . ($debateHistory ?: 'None yet.') . "\n\n"
                        . "### Latest Bear Analyst Argument\n{$lastBearArg}\n\n"
                        . "Deliver your Round #{$round} Bullish Researcher argument now.",
                ],
            ];

            $llmRes = LLMClient::chat($messages, 'quick', $quickProv, $quickMod);
            return [
                'agent_role'   => "Bullish Researcher (Round #{$round})",
                'stage_group'  => 'research_debate',
                'round_number' => $round,
                'markdown'     => "**Bull Analyst (Round #{$round}):**\n\n" . $llmRes['content'],
                'provider'     => $llmRes['provider'],
                'model'        => $llmRes['model'],
                'tokens'       => $llmRes['tokens'],
                'latency_ms'   => $llmRes['latency_ms'],
            ];
        }

        // =====================================================================
        // 6. BEARISH RESEARCHER (`bear_researcher.py`)
        // =====================================================================
        if (preg_match('/^bear_round_(\d+)$/', $stepKey, $m)) {
            $round = (int)$m[1];
            $debateHistory = self::buildDebateTranscript($existingReports, 'research_debate');
            $lastBullArg   = $existingReports['bull_round_' . $round]['report_markdown'] ?? '(No bull argument found)';

            $messages = [
                [
                    'role' => 'system',
                    'content' => "You are a Bear Analyst making the case against investing in {$ticker}. Your goal is to present a rigorous, evidence-based argument emphasizing downside risks, valuation stretches, technical resistance/weaknesses, and macroeconomic threats. Directly counter the Bull Analyst's points.\n"
                        . "Key points to focus on:\n"
                        . "- Risks and Challenges: Valuation compression, margin pressures, or macro headwinds.\n"
                        . "- Competitive Weaknesses: Threats to market share or execution risks.\n"
                        . "- Negative Indicators: Overbought technicals, bearish divergences, insider selling, or adverse news.\n"
                        . "- Bull Counterpoints: Expose overly optimistic assumptions in the Bull Analyst's argument.\n"
                        . "Present your argument in a direct, conversational debate style.{$langInstr}",
                ],
                [
                    'role' => 'user',
                    'content' => "{$instCtx}\n\n"
                        . "### Market / Technical Report\n{$marketRep}\n\n"
                        . "### Social Sentiment Report\n{$sentRep}\n\n"
                        . "### News & Macro Report\n{$newsRep}\n\n"
                        . "### Fundamentals Report\n{$fundRep}\n\n"
                        . "### Debate Transcript So Far\n{$debateHistory}\n\n"
                        . "### Latest Bull Analyst Argument\n{$lastBullArg}\n\n"
                        . "Deliver your Round #{$round} Bearish Researcher rebuttal now.",
                ],
            ];

            $llmRes = LLMClient::chat($messages, 'quick', $quickProv, $quickMod);
            return [
                'agent_role'   => "Bearish Researcher (Round #{$round})",
                'stage_group'  => 'research_debate',
                'round_number' => $round,
                'markdown'     => "**Bear Analyst (Round #{$round}):**\n\n" . $llmRes['content'],
                'provider'     => $llmRes['provider'],
                'model'        => $llmRes['model'],
                'tokens'       => $llmRes['tokens'],
                'latency_ms'   => $llmRes['latency_ms'],
            ];
        }

        // =====================================================================
        // 7. RESEARCH MANAGER (`research_manager.py` + `ResearchPlan` schema)
        // =====================================================================
        if ($stepKey === 'research_manager') {
            $debateHistory = self::buildDebateTranscript($existingReports, 'research_debate');

            $messages = [
                [
                    'role' => 'system',
                    'content' => "As the Research Manager and debate judge, critically evaluate the Bull vs. Bear debate for {$ticker} and deliver a clear, actionable investment plan for the Trader.\n"
                        . "{$instCtx}\n\n"
                        . "Rating Scale (choose exactly one):\n"
                        . "- Buy: Strong conviction in the bull thesis; recommend taking or growing the position\n"
                        . "- Overweight: Constructive view; recommend gradually increasing exposure\n"
                        . "- Hold: Balanced view; recommend maintaining current position\n"
                        . "- Underweight: Cautious view; recommend trimming exposure\n"
                        . "- Sell: Strong conviction in the bear thesis; recommend exiting or avoiding the position\n\n"
                        . "Conflicting arguments alone are not a reason to Hold: commit to the side with the stronger evidence. Return a valid JSON object with these exact keys:\n"
                        . "{\n"
                        . "  \"recommendation\": \"Buy\" | \"Overweight\" | \"Hold\" | \"Underweight\" | \"Sell\",\n"
                        . "  \"rationale\": \"Conversational summary weighing both sides and explaining which evidence decided the recommendation.\",\n"
                        . "  \"strategic_actions\": \"Concrete execution steps and allocation guidance for the Trader.\"\n"
                        . "}{$langInstr}",
                ],
                [
                    'role' => 'user',
                    'content' => "### Bull vs. Bear Debate History\n{$debateHistory}\n\n"
                        . "Produce the JSON ResearchPlan object (`recommendation`, `rationale`, `strategic_actions`) now.",
                ],
            ];

            $llmRes = LLMClient::chatStructured($messages, ['recommendation', 'rationale', 'strategic_actions'], 'deep', $deepProv, $deepMod);
            $struct = $llmRes['structured'];

            if (is_array($struct) && !empty($struct['recommendation'])) {
                $rec = self::normalizeFiveTierRating((string)$struct['recommendation']);
                $md  = "**Recommendation**: {$rec}\n\n**Rationale**: {$struct['rationale']}\n\n**Strategic Actions**: {$struct['strategic_actions']}";
            } else {
                $md  = $llmRes['content'];
                $rec = self::parseRatingFromText($md);
            }

            Database::query("UPDATE `analyses` SET `research_recommendation` = :r WHERE `id` = :id", [':r' => $rec, ':id' => $analysisId]);

            return [
                'agent_role'  => 'Research Manager (Debate Judge)',
                'stage_group' => 'research_debate',
                'markdown'    => $md,
                'structured'  => $struct,
                'provider'    => $llmRes['provider'],
                'model'       => $llmRes['model'],
                'tokens'      => $llmRes['tokens'],
                'latency_ms'  => $llmRes['latency_ms'],
            ];
        }

        // =====================================================================
        // 8. TRADER AGENT (`trader.py` + `TraderProposal` schema)
        // =====================================================================
        if ($stepKey === 'trader') {
            $investmentPlan = $existingReports['research_manager']['report_markdown'] ?? '';

            $messages = [
                [
                    'role' => 'system',
                    'content' => "You are the Desk Trader analyzing the Research Manager's investment plan and Technical Market Report for {$ticker} to produce a concrete transaction proposal.\n"
                        . "Ground concrete price levels (`entry_price` and `stop_loss`) in the Technical Market Report's actual price, ATR, and support/resistance structure. State `entry_price` and `stop_loss` strictly as numeric prices in the instrument's currency (e.g. 189.50), never percentages.\n\n"
                        . "Return a valid JSON object with these exact keys:\n"
                        . "{\n"
                        . "  \"action\": \"Buy\" | \"Hold\" | \"Sell\",\n"
                        . "  \"reasoning\": \"2-4 sentences anchoring the action in the research plan and price structure.\",\n"
                        . "  \"entry_price\": number or null,\n"
                        . "  \"stop_loss\": number or null,\n"
                        . "  \"position_sizing\": \"e.g. '5% of portfolio (scaled in 2 tranches)'\"\n"
                        . "}{$langInstr}",
                ],
                [
                    'role' => 'user',
                    'content' => "{$instCtx}\n\n{$portCtx}\n\n"
                        . "### Technical Market Report\n{$marketRep}\n\n"
                        . "### Research Manager's Proposed Investment Plan\n{$investmentPlan}\n\n"
                        . "Respond with the JSON TraderProposal object now.",
                ],
            ];

            $llmRes = LLMClient::chatStructured($messages, ['action', 'reasoning'], 'quick', $quickProv, $quickMod);
            $struct = $llmRes['structured'];

            if (is_array($struct) && !empty($struct['action'])) {
                $rawAct = ucfirst(strtolower(trim((string)$struct['action'])));
                $action = in_array($rawAct, ['Buy', 'Hold', 'Sell'], true) ? $rawAct : 'Hold';
                $entry  = self::coerceFloat($struct['entry_price'] ?? null);
                $stop   = self::coerceFloat($struct['stop_loss'] ?? null);
                $sizing = trim((string)($struct['position_sizing'] ?? 'not provided'));

                $md = implode("\n\n", [
                    "**Action**: {$action}",
                    "**Reasoning**: " . ($struct['reasoning'] ?? ''),
                    "**Entry Price**: " . ($entry !== null ? (string)$entry : 'not provided'),
                    "**Stop Loss**: " . ($stop !== null ? (string)$stop : 'not provided'),
                    "**Position Sizing**: " . ($sizing !== '' ? $sizing : 'not provided'),
                    "FINAL TRANSACTION PROPOSAL: **" . strtoupper($action) . "**",
                ]);

                Database::query(
                    "UPDATE `analyses` SET `trader_action` = :act, `entry_price` = :ep, `stop_loss` = :sl, `position_sizing` = :sz WHERE `id` = :id",
                    [':act' => $action, ':ep' => $entry, ':sl' => $stop, ':sz' => mb_substr($sizing, 0, 120), ':id' => $analysisId]
                );
            } else {
                $md = $llmRes['content'];
            }

            return [
                'agent_role'  => 'Trader Agent',
                'stage_group' => 'trader_desk',
                'markdown'    => $md,
                'structured'  => $struct,
                'provider'    => $llmRes['provider'],
                'model'       => $llmRes['model'],
                'tokens'      => $llmRes['tokens'],
                'latency_ms'  => $llmRes['latency_ms'],
            ];
        }

        // =====================================================================
        // 9. RISK MANAGEMENT TEAM (`aggressive_debator.py`, `conservative_debator.py`, `neutral_debator.py`)
        // =====================================================================
        if (preg_match('/^risk_(aggressive|conservative|neutral)_(\d+)$/', $stepKey, $m)) {
            $stance = $m[1];
            $round  = (int)$m[2];
            $traderPlan  = $existingReports['trader']['report_markdown'] ?? '';
            $riskHistory = self::buildDebateTranscript($existingReports, 'risk_committee');

            $stancePrompts = [
                'aggressive' => [
                    'role_title' => "Aggressive Risk Analyst (Round #{$round})",
                    'persona'    => "As the Aggressive Risk Analyst, your role is to actively champion high-reward, high-conviction opportunities, emphasizing asymmetric upside, momentum catalysts, and competitive advantages. Critique overly timid assumptions from the Conservative and Neutral analysts and argue how best to capture upside in the Trader's proposal.",
                ],
                'conservative' => [
                    'role_title' => "Conservative Risk Analyst (Round #{$round})",
                    'persona'    => "As the Conservative Risk Analyst, your primary objective is capital preservation, drawdown mitigation, and tail-risk defense. Critically examine the Trader's proposal and challenge the Aggressive and Neutral analysts by pointing out downside vulnerabilities, stop-loss placement, macro/valuation risks, and position-sizing limits.",
                ],
                'neutral' => [
                    'role_title' => "Neutral Risk Analyst (Round #{$round})",
                    'persona'    => "As the Neutral Risk Analyst, your role is to provide a balanced, risk-adjusted perspective weighing both upside potential and downside protection. Challenge where the Aggressive Analyst is overly optimistic and where the Conservative Analyst is overly cautious, advocating for disciplined risk-reward calibration.",
                ],
            ];

            $meta = $stancePrompts[$stance];

            $messages = [
                [
                    'role'    => 'system',
                    'content' => $meta['persona'] . "\nEngage directly with the other risk analysts' arguments in a natural conversational debate style.{$langInstr}",
                ],
                [
                    'role'    => 'user',
                    'content' => "{$instCtx}\n{$portCtx}\n\n"
                        . "### Trader's Transaction Proposal\n{$traderPlan}\n\n"
                        . "### Summary of Analyst Reports\n"
                        . "- **Market/Technical**: " . mb_substr($marketRep, 0, 1200) . "\n"
                        . "- **Sentiment**: " . mb_substr($sentRep, 0, 800) . "\n"
                        . "- **News/Macro**: " . mb_substr($newsRep, 0, 800) . "\n"
                        . "- **Fundamentals**: " . mb_substr($fundRep, 0, 1000) . "\n\n"
                        . "### Risk Committee Debate History So Far\n" . ($riskHistory ?: 'Opening statement.') . "\n\n"
                        . "Deliver your {$meta['role_title']} evaluation now.",
                ],
            ];

            $llmRes = LLMClient::chat($messages, 'quick', $quickProv, $quickMod);
            $speakerPrefix = ucfirst($stance) . " Risk Analyst (Round #{$round})";

            return [
                'agent_role'   => $meta['role_title'],
                'stage_group'  => 'risk_committee',
                'round_number' => $round,
                'markdown'     => "**{$speakerPrefix}:**\n\n" . $llmRes['content'],
                'provider'     => $llmRes['provider'],
                'model'        => $llmRes['model'],
                'tokens'       => $llmRes['tokens'],
                'latency_ms'   => $llmRes['latency_ms'],
            ];
        }

        // =====================================================================
        // 10. PORTFOLIO MANAGER (`portfolio_manager.py` + `PortfolioDecision` schema)
        // =====================================================================
        if ($stepKey === 'portfolio_manager') {
            $researchPlan = $existingReports['research_manager']['report_markdown'] ?? '';
            $traderPlan   = $existingReports['trader']['report_markdown'] ?? '';
            $riskHistory  = self::buildDebateTranscript($existingReports, 'risk_committee');

            $messages = [
                [
                    'role' => 'system',
                    'content' => "As the Portfolio Manager, synthesize the Research Manager's plan, the Trader's proposal, past lessons, and the Risk Management Committee's debate to deliver the final binding trading decision for {$ticker} as of {$tradeDate}.\n\n"
                        . "Rating Scale (use exactly one):\n"
                        . "- Buy: Strong conviction to enter or add to position\n"
                        . "- Overweight: Favorable outlook, gradually increase exposure\n"
                        . "- Hold: Maintain current position, no action needed\n"
                        . "- Underweight: Reduce exposure, take partial profits\n"
                        . "- Sell: Exit position or avoid entry\n\n"
                        . "Ground every conclusion in specific evidence from the analysts. Conflicting arguments alone are not a reason to Hold: commit to the stronger case, sized by how decisively it wins.\n\n"
                        . "Return a valid JSON object with these exact keys:\n"
                        . "{\n"
                        . "  \"rating\": \"Buy\" | \"Overweight\" | \"Hold\" | \"Underweight\" | \"Sell\",\n"
                        . "  \"executive_summary\": \"Concise 2-4 sentence action plan covering entry strategy, position sizing, key risk levels, and time horizon.\",\n"
                        . "  \"investment_thesis\": \"Detailed multi-paragraph reasoning anchored in specific evidence from the technical, sentiment, news, fundamental, and risk debates.\",\n"
                        . "  \"price_target\": number or null,\n"
                        . "  \"time_horizon\": \"e.g. '3-6 months' or '2-4 weeks'\"\n"
                        . "}{$langInstr}",
                ],
                [
                    'role' => 'user',
                    'content' => "{$instCtx}\n{$portCtx}\n"
                        . ($pastCtx !== '' ? "\n### Prior Memory Log & Lessons\n{$pastCtx}\n" : '')
                        . "\n### Research Manager's Investment Plan\n{$researchPlan}\n\n"
                        . "### Trader's Transaction Proposal\n{$traderPlan}\n\n"
                        . "### Risk Management Committee Debate\n{$riskHistory}\n\n"
                        . "Produce the final JSON PortfolioDecision object now.",
                ],
            ];

            $llmRes = LLMClient::chatStructured($messages, ['rating', 'executive_summary', 'investment_thesis'], 'deep', $deepProv, $deepMod);
            $struct = $llmRes['structured'];

            if (is_array($struct) && !empty($struct['rating'])) {
                $rating  = self::normalizeFiveTierRating((string)$struct['rating']);
                $execSum = trim((string)($struct['executive_summary'] ?? ''));
                $thesis  = trim((string)($struct['investment_thesis'] ?? ''));
                $target  = self::coerceFloat($struct['price_target'] ?? null);
                $horizon = trim((string)($struct['time_horizon'] ?? 'not provided'));

                $md = implode("\n\n", [
                    "**Rating**: {$rating}",
                    "**Executive Summary**: {$execSum}",
                    "**Investment Thesis**: {$thesis}",
                    "**Price Target**: " . ($target !== null ? (string)$target : 'not provided'),
                    "**Time Horizon**: " . ($horizon !== '' ? $horizon : 'not provided'),
                ]);
            } else {
                $md      = $llmRes['content'];
                $rating  = self::parseRatingFromText($md);
                $execSum = mb_substr(strip_tags($md), 0, 500);
                $thesis  = $md;
                $target  = null;
                $horizon = 'Medium-Term';
            }

            // Build complete state JSON matching TradingAgents full_states_log_{date}.json
            $fullState = [
                'company_of_interest'   => $ticker,
                'trade_date'            => $tradeDate,
                'instrument_context'    => $instCtx,
                'market_report'         => $marketRep,
                'sentiment_report'      => $sentRep,
                'news_report'           => $newsRep,
                'fundamentals_report'   => $fundRep,
                'investment_plan'       => $researchPlan,
                'trader_investment_plan'=> $traderPlan,
                'final_trade_decision'  => $md,
                'final_rating'          => $rating,
            ];

            Database::query(
                "UPDATE `analyses`
                 SET `final_rating` = :rat,
                     `price_target` = :pt,
                     `time_horizon` = :th,
                     `executive_summary` = :es,
                     `investment_thesis` = :it,
                     `full_state_json` = :fjson
                 WHERE `id` = :id",
                [
                    ':rat'   => $rating,
                    ':pt'    => $target,
                    ':th'    => mb_substr($horizon, 0, 120),
                    ':es'    => $execSum,
                    ':it'    => $thesis,
                    ':fjson' => json_encode($fullState, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
                    ':id'    => $analysisId,
                ]
            );

            // Store decision in `trading_memory` for future reflection & alpha calculation
            $holdDays  = (int)Database::getSetting('holding_period_days', '5');
            $bench     = (string)Database::getSetting('benchmark_ticker', 'SPY');
            Database::query(
                "INSERT INTO `trading_memory`
                 (`analysis_id`, `ticker`, `trade_date`, `rating`, `price_at_decision`, `benchmark_ticker`, `holding_period_days`, `outcome_status`, `decision_summary`)
                 VALUES (:aid, :t, :td, :rat, :pr, :bm, :hd, 'pending', :sum)",
                [
                    ':aid' => $analysisId,
                    ':t'   => $ticker,
                    ':td'  => $tradeDate,
                    ':rat' => $rating,
                    ':pr'  => $analysis['market_price_at_analysis'] ?? null,
                    ':bm'  => $bench,
                    ':hd'  => max(1, $holdDays),
                    ':sum' => $execSum ?: mb_substr($md, 0, 600),
                ]
            );

            // Update any matching watchlist entry for this ticker
            Database::query(
                "UPDATE `watchlists`
                 SET `last_price` = COALESCE(:pr, `last_price`),
                     `last_rating` = :rat,
                     `last_analysis_id` = :aid
                 WHERE `ticker` = :t",
                [
                    ':pr'  => $analysis['market_price_at_analysis'] ?? null,
                    ':rat' => $rating,
                    ':aid' => $analysisId,
                    ':t'   => $ticker,
                ]
            );

            return [
                'agent_role'  => 'Portfolio Manager (Final Decision)',
                'stage_group' => 'portfolio_manager',
                'markdown'    => $md,
                'structured'  => $struct,
                'provider'    => $llmRes['provider'],
                'model'       => $llmRes['model'],
                'tokens'      => $llmRes['tokens'],
                'latency_ms'  => $llmRes['latency_ms'],
            ];
        }

        throw new RuntimeException("Unknown agent workflow step: {$stepKey}");
    }

    public static function getReports(int $analysisId): array
    {
        return Database::fetchAll(
            "SELECT * FROM `agent_reports` WHERE `analysis_id` = :aid ORDER BY `id` ASC",
            [':aid' => $analysisId]
        );
    }

    public static function getReportsByKey(int $analysisId): array
    {
        $rows = self::getReports($analysisId);
        $map = [];
        foreach ($rows as $r) {
            $map[$r['step_key']] = $r;
        }
        return $map;
    }

    public static function getQueue(int $analysisId): array
    {
        return Database::fetchAll(
            "SELECT * FROM `analysis_queue` WHERE `analysis_id` = :aid ORDER BY `step_order` ASC",
            [':aid' => $analysisId]
        );
    }

    private static function buildDebateTranscript(array $reportsByKey, string $stageGroup): string
    {
        $chunks = [];
        foreach ($reportsByKey as $key => $row) {
            if (($row['stage_group'] ?? '') === $stageGroup && $key !== 'research_manager') {
                $chunks[] = $row['report_markdown'];
            }
        }
        return implode("\n\n---\n\n", $chunks);
    }

    private static function buildPortfolioContext(int $userId, string $ticker): string
    {
        $port = Database::fetchOne(
            "SELECT * FROM `portfolios` WHERE `user_id` = :uid ORDER BY `is_default` DESC, `id` ASC LIMIT 1",
            [':uid' => $userId]
        );
        if (!$port) {
            return '';
        }
        $positions = Database::fetchAll(
            "SELECT * FROM `portfolio_positions` WHERE `portfolio_id` = :pid AND `status` = 'open'",
            [':pid' => $port['id']]
        );

        $lines = [
            "Caller Portfolio Context: Cash Balance = $" . number_format((float)$port['cash_balance'], 2) . " {$port['base_currency']}",
        ];
        foreach ($positions as $pos) {
            $marker = ($pos['ticker'] === $ticker) ? ' [TARGET INSTRUMENT HELD]' : '';
            $lines[] = sprintf(
                "- %s %s: %s shares/units @ avg entry $%s%s",
                $pos['side'],
                $pos['ticker'],
                (float)$pos['quantity'],
                number_format((float)$pos['avg_entry_price'], 2),
                $marker
            );
        }
        return implode("\n", $lines);
    }

    private static function buildPastMemoryContext(string $ticker, string $tradeDate): string
    {
        $memories = Database::fetchAll(
            "SELECT * FROM `trading_memory`
             WHERE (`ticker` = :t OR `outcome_status` = 'settled')
               AND `trade_date` < :td
             ORDER BY (`ticker` = :t2) DESC, `trade_date` DESC
             LIMIT 5",
            [':t' => $ticker, ':td' => $tradeDate, ':t2' => $ticker]
        );
        if (empty($memories)) {
            return '';
        }
        $lines = [];
        foreach ($memories as $m) {
            $alpha = $m['alpha_return_pct'] !== null ? sprintf(' | Alpha vs %s: %+.2f%%', $m['benchmark_ticker'], (float)$m['alpha_return_pct']) : '';
            $lesson = !empty($m['reflection_lesson']) ? "\n  Lesson: {$m['reflection_lesson']}" : '';
            $lines[] = "- [{$m['trade_date']} | {$m['ticker']} | Rating: {$m['rating']}{$alpha}] {$m['decision_summary']}{$lesson}";
        }
        return implode("\n", $lines);
    }

    public static function normalizeFiveTierRating(string $raw): string
    {
        $clean = strtolower(trim($raw));
        return match (true) {
            str_contains($clean, 'overweight')  => 'Overweight',
            str_contains($clean, 'underweight') => 'Underweight',
            str_contains($clean, 'buy')         => 'Buy',
            str_contains($clean, 'sell')        => 'Sell',
            str_contains($clean, 'hold')        => 'Hold',
            default                             => 'Hold',
        };
    }

    public static function parseRatingFromText(string $text): string
    {
        if (preg_match('/\*\*(?:Rating|Recommendation)\*\*:\s*\*?\*?(Buy|Overweight|Hold|Underweight|Sell)\b/i', $text, $m)) {
            return self::normalizeFiveTierRating($m[1]);
        }
        return self::normalizeFiveTierRating($text);
    }

    private static function coerceFloat(mixed $val): ?float
    {
        if ($val === null || $val === '') {
            return null;
        }
        if (is_int($val) || is_float($val)) {
            return (float)$val;
        }
        $str = trim((string)$val);
        if ($str === '' || str_ends_with($str, '%') || in_array(strtolower($str), ['none', 'n/a', 'null', 'not provided', '-'], true)) {
            return null;
        }
        $cleaned = preg_replace('/[^0-9.\-]/', '', $str);
        return ($cleaned !== '' && is_numeric($cleaned)) ? (float)$cleaned : null;
    }

    private static function uuidV4(): string
    {
        $data = random_bytes(16);
        $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
        $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}
