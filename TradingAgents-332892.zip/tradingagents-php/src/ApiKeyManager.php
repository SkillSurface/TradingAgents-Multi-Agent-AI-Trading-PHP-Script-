<?php
/**
 * TradingAgents PHP 8.4 — Enterprise AI API Key Management Vault
 *
 * Includes `getAllActiveLlmKeys()` and smart OpenRouter key detection (`sk-or-...` or `openrouter.ai` base URL).
 */

declare(strict_types=1);

namespace TradingAgents;

use RuntimeException;
use Throwable;

final class ApiKeyManager
{
    public static function listKeys(?string $category = null): array
    {
        $sql = "SELECT `id`, `provider_slug`, `provider_category`, `key_label`, `key_hint`, `base_url`,
                       `tier_type`, `priority`, `is_enabled`, `verification_status`, `last_verified_at`,
                       `last_used_at`, `cooldown_until`, `total_requests`, `failed_requests`,
                       `total_tokens`, `last_error`, `created_at`
                FROM `api_keys`";
        $params = [];
        if ($category !== null && $category !== '') {
            $sql .= " WHERE `provider_category` = :cat";
            $params[':cat'] = $category;
        }
        $sql .= " ORDER BY `provider_slug` ASC, `priority` ASC, `id` ASC";
        return Database::fetchAll($sql, $params);
    }

    public static function addKey(
        string $providerSlug,
        string $keyLabel,
        string $plainKey,
        string $tierType = 'free',
        int $priority = 10,
        ?string $baseUrl = null,
        ?int $userId = null
    ): int {
        $plainKey = trim($plainKey);
        if ($plainKey === '') {
            throw new RuntimeException('API key cannot be empty.');
        }

        // Auto-detect if user pasted an OpenRouter key or OpenRouter base URL
        if (str_starts_with($plainKey, 'sk-or-') || ($baseUrl !== null && str_contains(strtolower($baseUrl), 'openrouter.ai'))) {
            $baseUrl = 'https://openrouter.ai/api/v1';
        }

        $providers = ModelCatalog::getProviders();
        $provMeta  = $providers[$providerSlug] ?? null;
        $category  = $provMeta['category'] ?? 'llm';

        $encrypted = Security::encrypt($plainKey);
        $hint      = Security::maskKey($plainKey);

        $id = Database::insert(
            "INSERT INTO `api_keys`
             (`provider_slug`, `provider_category`, `key_label`, `encrypted_key`, `key_hint`, `base_url`, `tier_type`, `priority`, `is_enabled`, `verification_status`, `created_by`)
             VALUES (:slug, :cat, :lbl, :enc, :hint, :url, :tier, :prio, 1, 'unverified', :uid)",
            [
                ':slug' => strtolower(trim($providerSlug)),
                ':cat'  => $category,
                ':lbl'  => trim($keyLabel) ?: ($provMeta['name'] ?? $providerSlug) . ' Key',
                ':enc'  => $encrypted,
                ':hint' => $hint,
                ':url'  => $baseUrl ? trim($baseUrl) : null,
                ':tier' => in_array($tierType, ['free', 'paid', 'trial'], true) ? $tierType : 'free',
                ':prio' => max(1, min(999, $priority)),
                ':uid'  => $userId,
            ]
        );

        Logger::log('SECURITY', 'api_key', "Added API key #{$id} for provider {$providerSlug} ({$hint})", $userId);
        return $id;
    }

    public static function toggleKey(int $id, bool $enable): void
    {
        Database::query(
            "UPDATE `api_keys` SET `is_enabled` = :en, `cooldown_until` = NULL WHERE `id` = :id",
            [':en' => $enable ? 1 : 0, ':id' => $id]
        );
        Logger::log('SECURITY', 'api_key', ($enable ? 'Enabled' : 'Disabled') . " API key #{$id}");
    }

    public static function resetKeyStats(int $id): void
    {
        Database::query(
            "UPDATE `api_keys`
             SET `total_requests` = 0, `failed_requests` = 0, `total_tokens` = 0,
                 `cooldown_until` = NULL, `last_error` = NULL, `verification_status` = 'unverified'
             WHERE `id` = :id",
            [':id' => $id]
        );
        Logger::log('INFO', 'api_key', "Reset counters & cooldown for API key #{$id}");
    }

    public static function deleteKey(int $id): void
    {
        Database::query("DELETE FROM `api_keys` WHERE `id` = :id", [':id' => $id]);
        Logger::log('SECURITY', 'api_key', "Deleted API key #{$id}");
    }

    public static function getActiveKeysForProvider(string $providerSlug): array
    {
        $rows = Database::fetchAll(
            "SELECT * FROM `api_keys`
             WHERE `provider_slug` = :slug AND `is_enabled` = 1
             ORDER BY
               CASE WHEN `cooldown_until` IS NULL OR `cooldown_until` <= NOW() THEN 0 ELSE 1 END ASC,
               `priority` ASC,
               `total_requests` ASC,
               `id` ASC",
            [':slug' => strtolower(trim($providerSlug))]
        );

        $candidates = [];
        foreach ($rows as $row) {
            try {
                $row['decrypted_key'] = Security::decrypt((string)$row['encrypted_key']);
                $candidates[] = $row;
            } catch (Throwable $e) {
                Logger::log('ERROR', 'api_key', "Failed to decrypt key #{$row['id']}: " . $e->getMessage());
            }
        }
        return $candidates;
    }

    /**
     * Returns all active LLM keys across any provider (used as fallback when an OpenRouter key
     * was saved under `openrouter` or `anthropic` with `https://openrouter.ai/api/v1`).
     */
    public static function getAllActiveLlmKeys(): array
    {
        $rows = Database::fetchAll(
            "SELECT * FROM `api_keys`
             WHERE `provider_category` = 'llm' AND `is_enabled` = 1
             ORDER BY
               CASE WHEN `cooldown_until` IS NULL OR `cooldown_until` <= NOW() THEN 0 ELSE 1 END ASC,
               `priority` ASC,
               `id` ASC"
        );
        $candidates = [];
        foreach ($rows as $row) {
            try {
                $row['decrypted_key'] = Security::decrypt((string)$row['encrypted_key']);
                $candidates[] = $row;
            } catch (Throwable) {
            }
        }
        return $candidates;
    }

    public static function getVendorKey(string $vendorSlug): ?string
    {
        $keys = self::getActiveKeysForProvider($vendorSlug);
        return $keys[0]['decrypted_key'] ?? null;
    }

    public static function recordSuccess(int $keyId, int $tokens = 0): void
    {
        Database::query(
            "UPDATE `api_keys`
             SET `total_requests` = `total_requests` + 1,
                 `total_tokens` = `total_tokens` + :tok,
                 `last_used_at` = NOW(),
                 `verification_status` = 'valid',
                 `cooldown_until` = NULL,
                 `last_error` = NULL
             WHERE `id` = :id",
            [':tok' => max(0, $tokens), ':id' => $keyId]
        );
    }

    public static function recordFailure(int $keyId, int $httpCode, string $errorMessage): void
    {
        $safeErr = mb_substr(Logger::scrub($errorMessage), 0, 480);
        $status  = 'valid';
        $cooldownSql = "NULL";

        if ($httpCode === 401 || $httpCode === 403) {
            $status = 'invalid';
        } elseif ($httpCode === 402) {
            $status = 'quota_exceeded';
            $cooldownSql = "DATE_ADD(NOW(), INTERVAL 30 MINUTE)";
        } elseif ($httpCode === 429 || str_contains(strtolower($errorMessage), 'rate limit')) {
            $status = 'rate_limited';
            $cooldownSql = "DATE_ADD(NOW(), INTERVAL 90 SECOND)";
        }

        Database::query(
            "UPDATE `api_keys`
             SET `total_requests` = `total_requests` + 1,
                 `failed_requests` = `failed_requests` + 1,
                 `last_used_at` = NOW(),
                 `verification_status` = :st,
                 `cooldown_until` = {$cooldownSql},
                 `last_error` = :err
             WHERE `id` = :id",
            [':st' => $status, ':err' => $safeErr, ':id' => $keyId]
        );
    }

    public static function verifyKey(int $keyId): array
    {
        $row = Database::fetchOne("SELECT * FROM `api_keys` WHERE `id` = :id LIMIT 1", [':id' => $keyId]);
        if (!$row) {
            return ['ok' => false, 'error' => 'API Key not found.'];
        }

        try {
            $plainKey = Security::decrypt((string)$row['encrypted_key']);
        } catch (Throwable $e) {
            return ['ok' => false, 'error' => 'Decryption failed: ' . $e->getMessage()];
        }

        $slug = (string)$row['provider_slug'];
        $baseUrl = (string)($row['base_url'] ?? '');
        $providers = ModelCatalog::getProviders();
        $meta = $providers[$slug] ?? null;

        $startTime = microtime(true);

        if ($slug === 'alphavantage') {
            $url = 'https://www.alphavantage.co/query?function=GLOBAL_QUOTE&symbol=IBM&apikey=' . urlencode($plainKey);
            $res = self::simpleGet($url);
            $ok = $res['http_code'] === 200 && !str_contains($res['body'], 'Error Message') && !str_contains($res['body'], 'Invalid API call');
            $latency = (int)round((microtime(true) - $startTime) * 1000);
            self::updateVerificationStatus($keyId, $ok ? 'valid' : 'invalid', $ok ? null : 'Alpha Vantage validation failed');
            return [
                'ok' => $ok,
                'latency_ms' => $latency,
                'message' => $ok ? "Alpha Vantage key verified ({$latency} ms)." : 'Invalid Alpha Vantage key or rate limited.',
            ];
        }

        if ($slug === 'fred') {
            $url = 'https://api.stlouisfed.org/fred/series?series_id=GNPCA&file_type=json&api_key=' . urlencode($plainKey);
            $res = self::simpleGet($url);
            $ok = $res['http_code'] === 200 && str_contains($res['body'], 'seriess');
            $latency = (int)round((microtime(true) - $startTime) * 1000);
            self::updateVerificationStatus($keyId, $ok ? 'valid' : 'invalid', $ok ? null : 'FRED validation failed');
            return [
                'ok' => $ok,
                'latency_ms' => $latency,
                'message' => $ok ? "FRED macro key verified ({$latency} ms)." : 'FRED returned HTTP ' . $res['http_code'],
            ];
        }

        // OpenRouter check (including keys saved under another provider slug with openrouter.ai base URL or sk-or- prefix)
        if ($slug === 'openrouter' || str_starts_with($plainKey, 'sk-or-') || str_contains(strtolower($baseUrl), 'openrouter.ai')) {
            $res = self::simpleGet('https://openrouter.ai/api/v1/auth/key', [
                'Authorization: Bearer ' . $plainKey,
            ]);
            $latency = (int)round((microtime(true) - $startTime) * 1000);
            if ($res['http_code'] === 200) {
                $data = json_decode($res['body'], true)['data'] ?? [];
                $label = $data['label'] ?? 'Verified';
                $isFree = !empty($data['is_free_tier']) ? 'Free Tier' : 'Paid Credits Active';
                self::updateVerificationStatus($keyId, 'valid', null);
                return [
                    'ok' => true,
                    'latency_ms' => $latency,
                    'message' => "OpenRouter Key Valid ({$isFree}, Label: {$label}, {$latency} ms).",
                ];
            }
            self::updateVerificationStatus($keyId, 'invalid', 'HTTP ' . $res['http_code']);
            return [
                'ok' => false,
                'latency_ms' => $latency,
                'error' => 'OpenRouter key validation failed (HTTP ' . $res['http_code'] . ').',
            ];
        }

        $testModel = ($row['tier_type'] === 'paid')
            ? ($meta['default_paid_model'] ?? 'gpt-4o-mini')
            : ($meta['default_free_model'] ?? 'gpt-4o-mini');

        $testRes = LLMClient::testSingleKey($slug, $plainKey, $testModel, $baseUrl ?: ($meta['base_url'] ?? null));
        $latency = (int)round((microtime(true) - $startTime) * 1000);

        if ($testRes['ok']) {
            self::updateVerificationStatus($keyId, 'valid', null);
            return [
                'ok' => true,
                'latency_ms' => $latency,
                'message' => "Verified {$slug} with model {$testRes['model']} ({$latency} ms).",
            ];
        }

        self::updateVerificationStatus($keyId, $testRes['status'] ?? 'invalid', $testRes['error'] ?? 'Verification failed');
        return [
            'ok' => false,
            'latency_ms' => $latency,
            'error' => $testRes['error'] ?? 'Key verification failed.',
        ];
    }

    private static function updateVerificationStatus(int $keyId, string $status, ?string $error): void
    {
        Database::query(
            "UPDATE `api_keys`
             SET `verification_status` = :st, `last_verified_at` = NOW(), `last_error` = :err
             WHERE `id` = :id",
            [':st' => $status, ':err' => $error ? mb_substr(Logger::scrub($error), 0, 480) : null, ':id' => $keyId]
        );
    }

    private static function simpleGet(string $url, array $headers = []): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_HTTPHEADER     => array_merge(['Accept: application/json', 'User-Agent: TradingAgentsPHP/2.0'], $headers),
        ]);
        $body = (string)curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ['http_code' => $code, 'body' => $body];
    }
}
