<?php
/**
 * TradingAgents PHP 8.4 — Application Bootstrap, Autoloader & Error Handler
 *
 * Strictly compatible with PHP 8.4 and Namecheap Linux Shared Hosting / cPanel (LiteSpeed).
 * Includes session lock release helper (`releaseSessionLock()`) so concurrent AJAX calls
 * and page navigations never deadlock or trigger LiteSpeed 404/503 timeouts.
 */

declare(strict_types=1);

namespace TradingAgents;

if (!defined('TA_APP_BOOTSTRAPPED')) {
    define('TA_APP_BOOTSTRAPPED', true);
}

define('TA_ROOT_DIR', dirname(__DIR__));
define('TA_SRC_DIR', __DIR__);
define('TA_CONFIG_PATH', TA_ROOT_DIR . '/config.php');

spl_autoload_register(static function (string $class): void {
    $prefix = 'TradingAgents\\';
    $baseDir = __DIR__ . '/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relativeClass = substr($class, $len);
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

    if (is_file($file)) {
        require_once $file;
    }
});

final class Bootstrap
{
    private static ?array $config = null;

    public static function init(bool $requireInstalled = true): array
    {
        if (self::$config !== null) {
            return self::$config;
        }

        if (!is_file(TA_CONFIG_PATH)) {
            if ($requireInstalled && php_sapi_name() !== 'cli') {
                header('Location: install.php');
                exit;
            }
            self::$config = require TA_ROOT_DIR . '/config.sample.php';
        } else {
            self::$config = require TA_CONFIG_PATH;
        }

        $tz = self::$config['app']['timezone'] ?? 'UTC';
        @date_default_timezone_set($tz);

        $debug = (bool)(self::$config['app']['debug'] ?? false);
        error_reporting(E_ALL);
        ini_set('display_errors', $debug ? '1' : '0');
        ini_set('log_errors', '1');
        @ini_set('memory_limit', '256M');

        $storageDir = self::$config['hosting']['storage_path'] ?? (TA_ROOT_DIR . '/storage');
        if (!is_dir($storageDir . '/logs')) {
            @mkdir($storageDir . '/logs', 0755, true);
        }
        ini_set('error_log', $storageDir . '/logs/php_error.log');

        if (php_sapi_name() !== 'cli' && session_status() === PHP_SESSION_NONE) {
            $sessName = self::$config['security']['session_name'] ?? 'TA_SESSID_SECURE';
            $lifetime = (int)(self::$config['security']['session_lifetime'] ?? 28800);
            $isHttps  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
                        || (($_SERVER['SERVER_PORT'] ?? 80) == 443)
                        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

            session_name($sessName);
            session_set_cookie_params([
                'lifetime' => $lifetime,
                'path'     => '/',
                'domain'   => '',
                'secure'   => $isHttps,
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
            session_start();
        }

        return self::$config;
    }

    /**
     * Releases the exclusive PHP session file lock after reading auth/CSRF state
     * so long-running LLM / Market Data HTTP requests never block page navigation on shared hosting.
     */
    public static function releaseSessionLock(): void
    {
        if (php_sapi_name() !== 'cli' && session_status() === PHP_SESSION_ACTIVE) {
            session_write_close();
        }
    }

    public static function config(?string $key = null, mixed $default = null): mixed
    {
        $cfg = self::init(false);
        if ($key === null) {
            return $cfg;
        }
        $segments = explode('.', $key);
        $curr = $cfg;
        foreach ($segments as $seg) {
            if (!is_array($curr) || !array_key_exists($seg, $curr)) {
                return $default;
            }
            $curr = $curr[$seg];
        }
        return $curr;
    }
}
