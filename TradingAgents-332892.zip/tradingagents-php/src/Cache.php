<?php
/**
 * TradingAgents PHP 8.4 — Two-Tier Market & API Cache Engine
 *
 * Uses MySQL (`market_cache` table) + optional filesystem cache (`/storage/cache`)
 * to minimize outbound HTTP calls and prevent rate limits on shared hosting.
 */

declare(strict_types=1);

namespace TradingAgents;

use Throwable;

final class Cache
{
    public static function get(string $key): mixed
    {
        $hashedKey = substr($key, 0, 140) . '_' . substr(md5($key), 0, 16);

        // 1. Check fast filesystem cache if enabled
        if (Bootstrap::config('hosting.enable_file_cache', true)) {
            $filePath = self::filePath($hashedKey);
            if (is_file($filePath)) {
                $raw = @file_get_contents($filePath);
                if ($raw !== false) {
                    $decoded = @json_decode($raw, true);
                    if (is_array($decoded) && isset($decoded['expires_at']) && $decoded['expires_at'] > time()) {
                        return $decoded['data'] ?? null;
                    }
                    @unlink($filePath);
                }
            }
        }

        // 2. Check MySQL `market_cache` table
        try {
            $row = Database::fetchOne(
                "SELECT `payload` FROM `market_cache` WHERE `cache_key` = :k AND `expires_at` > NOW() LIMIT 1",
                [':k' => $hashedKey]
            );
            if ($row && isset($row['payload'])) {
                $val = json_decode((string)$row['payload'], true);
                return $val !== null ? $val : $row['payload'];
            }
        } catch (Throwable) {
            // Fail open if cache table query fails
        }

        return null;
    }

    public static function set(string $key, mixed $data, int $ttlSeconds = 900, string $category = 'general', ?string $ticker = null): void
    {
        $hashedKey = substr($key, 0, 140) . '_' . substr(md5($key), 0, 16);
        $payload = is_string($data) ? $data : (string)json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $expiresTs = time() + max(10, $ttlSeconds);
        $expiresAt = gmdate('Y-m-d H:i:s', $expiresTs);

        // 1. Write to filesystem cache
        if (Bootstrap::config('hosting.enable_file_cache', true)) {
            $filePath = self::filePath($hashedKey);
            $dir = dirname($filePath);
            if (!is_dir($dir)) {
                @mkdir($dir, 0755, true);
            }
            @file_put_contents($filePath, json_encode([
                'expires_at' => $expiresTs,
                'data'       => $data,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
        }

        // 2. Write to MySQL `market_cache`
        try {
            Database::query(
                "INSERT INTO `market_cache` (`cache_key`, `ticker`, `data_category`, `payload`, `expires_at`)
                 VALUES (:k, :t, :c, :p, :e)
                 ON DUPLICATE KEY UPDATE `payload` = VALUES(`payload`), `expires_at` = VALUES(`expires_at`), `created_at` = NOW()",
                [
                    ':k' => $hashedKey,
                    ':t' => $ticker ? substr($ticker, 0, 32) : null,
                    ':c' => substr($category, 0, 48),
                    ':p' => $payload,
                    ':e' => $expiresAt,
                ]
            );
        } catch (Throwable) {
            // Ignore cache write errors
        }
    }

    public static function purgeExpired(): int
    {
        $deletedCount = 0;
        try {
            $stmt = Database::query("DELETE FROM `market_cache` WHERE `expires_at` <= NOW()");
            $deletedCount += $stmt->rowCount();
        } catch (Throwable) {
        }

        $dir = Bootstrap::config('hosting.storage_path', dirname(__DIR__) . '/storage') . '/cache';
        if (is_dir($dir)) {
            $files = glob($dir . '/*.cache.json') ?: [];
            $now = time();
            foreach ($files as $file) {
                $raw = @file_get_contents($file);
                $dec = $raw ? @json_decode($raw, true) : null;
                if (!is_array($dec) || ($dec['expires_at'] ?? 0) <= $now) {
                    if (@unlink($file)) {
                        $deletedCount++;
                    }
                }
            }
        }
        return $deletedCount;
    }

    public static function flushAll(): int
    {
        $deletedCount = 0;
        try {
            $stmt = Database::query("DELETE FROM `market_cache`");
            $deletedCount += $stmt->rowCount();
        } catch (Throwable) {
        }

        $dir = Bootstrap::config('hosting.storage_path', dirname(__DIR__) . '/storage') . '/cache';
        if (is_dir($dir)) {
            $files = glob($dir . '/*.cache.json') ?: [];
            foreach ($files as $file) {
                if (@unlink($file)) {
                    $deletedCount++;
                }
            }
        }
        return $deletedCount;
    }

    private static function filePath(string $hashedKey): string
    {
        $safe = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $hashedKey);
        $dir = Bootstrap::config('hosting.storage_path', dirname(__DIR__) . '/storage') . '/cache';
        return $dir . '/' . $safe . '.cache.json';
    }
}
