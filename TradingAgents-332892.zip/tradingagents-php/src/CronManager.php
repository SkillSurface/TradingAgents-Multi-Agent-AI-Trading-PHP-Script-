<?php
/**
 * TradingAgents PHP 8.4 — Cron Job & Maintenance Automation Engine
 *
 * Implements safe, non-destructive background maintenance & queue processing for cPanel:
 * 1. `queue_worker`: Advances pending multi-agent analysis steps in the background
 * 2. `memory_settlement`: Settles matured `trading_memory` decisions after `holding_period_days`,
 *    computes raw return & Alpha vs SPY, and calls the Reflector LLM to store lessons
 * 3. `cache_cleanup`: Deletes expired `market_cache` rows and stale `/storage/cache/*.cache.json` files
 * 4. `log_pruning`: Prunes outdated `system_logs` and `cron_logs` older than `log_retention_days`
 * 5. `db_optimize`: Runs `ANALYZE TABLE` on InnoDB tables to keep query plans fast without locking
 * 6. `watchlist_alerts`: Refreshes live prices on watched tickers and checks alert thresholds
 */

declare(strict_types=1);

namespace TradingAgents;

use Throwable;

final class CronManager
{
    /**
     * Returns metadata, recommended schedules, and cPanel commands for all cron jobs.
     */
    public static function getJobDefinitions(): array
    {
        $basePath = TA_ROOT_DIR;
        $cronScript = $basePath . '/cron.php';
        $token = (string)Database::getSetting('cron_secret_token', (string)Bootstrap::config('security.cron_token', ''));
        $siteUrl = rtrim((string)Bootstrap::config('app.url', ''), '/');
        if ($siteUrl === '' && isset($_SERVER['HTTP_HOST'])) {
            $proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $siteUrl = $proto . '://' . $_SERVER['HTTP_HOST'] . rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? ''), '/\\');
        }

        return [
            'all' => [
                'name'        => 'Master Cron Suite (Recommended Single cPanel Entry)',
                'schedule'    => '*/5 * * * * (Every 5 Minutes)',
                'purpose'     => 'Processes queued background AI agent steps, purges expired market cache, settles matured trading memory decisions, and prunes outdated logs.',
                'cli_cmd'     => "/usr/local/bin/php {$cronScript} --job=all >/dev/null 2>&1",
                'web_url'     => "{$siteUrl}/cron.php?token={$token}&job=all",
            ],
            'queue_worker' => [
                'name'        => 'Multi-Agent Background Queue Worker',
                'schedule'    => '* * * * * (Every Minute)',
                'purpose'     => 'Executes up to 3 pending agent steps per run for queued or background analyses so long multi-round debates finish without browser tab dependency.',
                'cli_cmd'     => "/usr/local/bin/php {$cronScript} --job=queue_worker >/dev/null 2>&1",
                'web_url'     => "{$siteUrl}/cron.php?token={$token}&job=queue_worker",
            ],
            'cache_cleanup' => [
                'name'        => 'Expired Market Data Cache Cleanup',
                'schedule'    => '0 * * * * (Hourly)',
                'purpose'     => 'Removes expired Yahoo Finance, SEC EDGAR, StockTwits, Reddit, and FRED cache entries from MySQL (`market_cache`) and `/storage/cache`.',
                'cli_cmd'     => "/usr/local/bin/php {$cronScript} --job=cache_cleanup >/dev/null 2>&1",
                'web_url'     => "{$siteUrl}/cron.php?token={$token}&job=cache_cleanup",
            ],
            'memory_settlement' => [
                'name'        => 'Trading Memory Settlement & AI Reflection',
                'schedule'    => '30 21 * * 1-5 (Weekdays after Market Close)',
                'purpose'     => 'Settles pending decisions whose holding window has elapsed, calculates raw return & Alpha vs Benchmark (SPY), and generates post-trade LLM lessons.',
                'cli_cmd'     => "/usr/local/bin/php {$cronScript} --job=memory_settlement >/dev/null 2>&1",
                'web_url'     => "{$siteUrl}/cron.php?token={$token}&job=memory_settlement",
            ],
            'log_pruning' => [
                'name'        => 'Outdated System & Cron Log Pruning',
                'schedule'    => '15 3 * * * (Daily at 03:15 UTC)',
                'purpose'     => 'Safely deletes `system_logs`, `cron_logs`, and failed queue entries older than the configured retention period (default 30 days) while preserving all user analyses and portfolios.',
                'cli_cmd'     => "/usr/local/bin/php {$cronScript} --job=log_pruning >/dev/null 2>&1",
                'web_url'     => "{$siteUrl}/cron.php?token={$token}&job=log_pruning",
            ],
            'db_optimize' => [
                'name'        => 'Database Table Statistics & Index Optimization',
                'schedule'    => '0 4 * * 0 (Weekly on Sunday at 04:00 UTC)',
                'purpose'     => 'Runs `ANALYZE TABLE` across all 13 InnoDB tables and resets expired API key rate-limit cooldowns to keep dashboard queries fast on shared hosting.',
                'cli_cmd'     => "/usr/local/bin/php {$cronScript} --job=db_optimize >/dev/null 2>&1",
                'web_url'     => "{$siteUrl}/cron.php?token={$token}&job=db_optimize",
            ],
            'watchlist_alerts' => [
                'name'        => 'Watchlist Price Refresh & Alert Check',
                'schedule'    => '*/15 * * * 1-5 (Every 15 Minutes on Trading Days)',
                'purpose'     => 'Updates latest quotes for watched symbols and logs notifications when price crosses user-defined Alert Above / Alert Below levels.',
                'cli_cmd'     => "/usr/local/bin/php {$cronScript} --job=watchlist_alerts >/dev/null 2>&1",
                'web_url'     => "{$siteUrl}/cron.php?token={$token}&job=watchlist_alerts",
            ],
        ];
    }

    /**
     * Executes a specific cron job (or `all`) and logs metrics to `cron_logs`.
     */
    public static function run(string $job = 'all', string $triggerSource = 'cli'): array
    {
        if ($job === 'all') {
            $results = [];
            foreach (['queue_worker', 'cache_cleanup', 'memory_settlement', 'log_pruning', 'watchlist_alerts', 'db_optimize'] as $subJob) {
                $results[$subJob] = self::runSingleJob($subJob, $triggerSource);
            }
            return [
                'ok'      => true,
                'job'     => 'all',
                'results' => $results,
            ];
        }

        return [
            'ok'      => true,
            'job'     => $job,
            'results' => [$job => self::runSingleJob($job, $triggerSource)],
        ];
    }

    private static function runSingleJob(string $jobName, string $triggerSource): array
    {
        $start = microtime(true);
        $items = 0;
        $status = 'success';
        $msg = '';

        try {
            switch ($jobName) {
                case 'queue_worker':
                    $activeAnalyses = Database::fetchAll(
                        "SELECT `id` FROM `analyses` WHERE `status` IN ('queued', 'running') ORDER BY `id` ASC LIMIT 2"
                    );
                    foreach ($activeAnalyses as $a) {
                        for ($step = 0; $step < 2; $step++) {
                            $res = AgentOrchestrator::executeNextStep((int)$a['id']);
                            $items++;
                            if (($res['status'] ?? '') === 'completed' || ($res['status'] ?? '') === 'failed') {
                                break;
                            }
                        }
                    }
                    $msg = $items > 0 ? "Processed {$items} queued agent step(s)." : 'No queued analysis steps pending.';
                    break;

                case 'cache_cleanup':
                    $items = Cache::purgeExpired();
                    $msg = "Purged {$items} expired market cache record(s)/file(s).";
                    break;

                case 'log_pruning':
                    $days = max(7, (int)Database::getSetting('log_retention_days', '30'));
                    $s1 = Database::query("DELETE FROM `system_logs` WHERE `created_at` < DATE_SUB(NOW(), INTERVAL {$days} DAY)");
                    $s2 = Database::query("DELETE FROM `cron_logs` WHERE `created_at` < DATE_SUB(NOW(), INTERVAL {$days} DAY)");
                    $items = $s1->rowCount() + $s2->rowCount();
                    $msg = "Pruned {$items} log record(s) older than {$days} days.";
                    break;

                case 'memory_settlement':
                    $settled = self::settlePendingMemories();
                    $items = $settled['count'];
                    $msg = $settled['message'];
                    break;

                case 'db_optimize':
                    $tables = [
                        'users', 'system_settings', 'api_keys', 'analyses', 'agent_reports',
                        'analysis_queue', 'trading_memory', 'portfolios', 'portfolio_positions',
                        'watchlists', 'market_cache', 'cron_logs', 'system_logs',
                    ];
                    foreach ($tables as $tbl) {
                        Database::query("ANALYZE TABLE `{$tbl}`");
                        $items++;
                    }
                    Database::query("UPDATE `api_keys` SET `cooldown_until` = NULL WHERE `cooldown_until` <= NOW()");
                    $msg = "Analyzed {$items} InnoDB tables and cleared expired API key cooldowns.";
                    break;

                case 'watchlist_alerts':
                    $watched = Database::fetchAll("SELECT DISTINCT `ticker` FROM `watchlists` LIMIT 15");
                    $today = gmdate('Y-m-d');
                    foreach ($watched as $w) {
                        $t = (string)$w['ticker'];
                        $q = MarketDataService::getOhlcvAndQuote($t, $today);
                        $latestPrice = $q['latest']['close'] ?? null;
                        $chgPct = $q['latest']['day_change_pct'] ?? null;
                        if ($latestPrice !== null) {
                            Database::query(
                                "UPDATE `watchlists` SET `last_price` = :p, `last_change_pct` = :c WHERE `ticker` = :t",
                                [':p' => $latestPrice, ':c' => $chgPct, ':t' => $t]
                            );
                            $items++;
                        }
                    }
                    $msg = "Updated live prices for {$items} watched symbol(s).";
                    break;

                default:
                    $status = 'warning';
                    $msg = "Unknown cron job '{$jobName}'.";
            }
        } catch (Throwable $e) {
            $status = 'error';
            $msg = Logger::scrub($e->getMessage());
        }

        $elapsedMs = (int)round((microtime(true) - $start) * 1000);

        try {
            Database::query(
                "INSERT INTO `cron_logs` (`job_name`, `trigger_source`, `status`, `items_processed`, `execution_time_ms`, `summary_message`)
                 VALUES (:j, :tr, :st, :it, :ms, :msg)",
                [
                    ':j'   => $jobName,
                    ':tr'  => in_array($triggerSource, ['cli', 'web_cron', 'admin_manual', 'ajax_fallback'], true) ? $triggerSource : 'cli',
                    ':st'  => $status,
                    ':it'  => $items,
                    ':ms'  => $elapsedMs,
                    ':msg' => $msg,
                ]
            );
        } catch (Throwable) {
        }

        return [
            'job'               => $jobName,
            'status'            => $status,
            'items_processed'   => $items,
            'execution_time_ms' => $elapsedMs,
            'message'           => $msg,
        ];
    }

    /**
     * Settles matured `trading_memory` entries and calls the Reflector prompt (matching `settlement.py` & `reflection.py`).
     */
    private static function settlePendingMemories(): array
    {
        $pending = Database::fetchAll(
            "SELECT * FROM `trading_memory`
             WHERE `outcome_status` = 'pending'
               AND `trade_date` <= DATE_SUB(CURDATE(), INTERVAL `holding_period_days` DAY)
             ORDER BY `trade_date` ASC
             LIMIT 3"
        );

        if (empty($pending)) {
            return ['count' => 0, 'message' => 'No pending trading memory entries due for settlement.'];
        }

        $settledCount = 0;
        $today = gmdate('Y-m-d');

        foreach ($pending as $row) {
            $ticker = (string)$row['ticker'];
            $bench  = (string)($row['benchmark_ticker'] ?: 'SPY');
            $days   = (int)($row['holding_period_days'] ?: 5);

            $tickerData = MarketDataService::getOhlcvAndQuote($ticker, $today);
            $benchData  = MarketDataService::getOhlcvAndQuote($bench, $today);

            $entryPrice = (float)($row['price_at_decision'] ?: ($tickerData['bars'][0]['close'] ?? 0));
            $exitPrice  = (float)($tickerData['latest']['close'] ?? 0);

            if ($entryPrice <= 0 || $exitPrice <= 0) {
                continue;
            }

            $rawReturnPct = round((($exitPrice - $entryPrice) / $entryPrice) * 100, 2);
            $benchBars = $benchData['bars'] ?? [];
            $benchReturnPct = 0.0;
            if (count($benchBars) >= 2) {
                $bStart = (float)$benchBars[max(0, count($benchBars) - $days - 1)]['close'];
                $bEnd   = (float)$benchBars[count($benchBars) - 1]['close'];
                if ($bStart > 0) {
                    $benchReturnPct = round((($bEnd - $bStart) / $bStart) * 100, 2);
                }
            }

            $alphaPct = round($rawReturnPct - $benchReturnPct, 2);

            // Generate post-trade reflection lesson via LLM (if key available)
            $lesson = sprintf(
                "Over %d trading days, %s returned %+.2f%% (Alpha vs %s: %+.2f%%) following a %s rating.",
                $days,
                $ticker,
                $rawReturnPct,
                $bench,
                $alphaPct,
                $row['rating']
            );

            try {
                $refRes = LLMClient::chat([
                    [
                        'role' => 'system',
                        'content' => "You are a trading analyst reviewing your own past decision now that the outcome is known over {$days} trading days. Write 2-3 concise sentences of plain prose covering: (1) What the {$days}-day alpha shows about the directional call, (2) Which part of the thesis held or failed, and (3) One concrete lesson for future analyses.",
                    ],
                    [
                        'role' => 'user',
                        'content' => "Raw return over {$days} days: {$rawReturnPct}%\nAlpha vs {$bench}: {$alphaPct}%\nRating: {$row['rating']}\nDecision Summary:\n{$row['decision_summary']}",
                    ],
                ], 'quick');
                if (!empty($refRes['content'])) {
                    $lesson = trim($refRes['content']);
                }
            } catch (Throwable) {
                // Keep deterministic lesson if LLM is unavailable
            }

            Database::query(
                "UPDATE `trading_memory`
                 SET `price_after_horizon` = :px,
                     `raw_return_pct` = :raw,
                     `benchmark_return_pct` = :bmr,
                     `alpha_return_pct` = :alp,
                     `outcome_status` = 'settled',
                     `settled_date` = CURDATE(),
                     `reflection_lesson` = :les
                 WHERE `id` = :id",
                [
                    ':px'  => $exitPrice,
                    ':raw' => $rawReturnPct,
                    ':bmr' => $benchReturnPct,
                    ':alp' => $alphaPct,
                    ':les' => $lesson,
                    ':id'  => $row['id'],
                ]
            );
            $settledCount++;
        }

        return [
            'count'   => $settledCount,
            'message' => "Settled {$settledCount} matured trading memory decision(s) with Alpha & reflection lessons.",
        ];
    }
}
