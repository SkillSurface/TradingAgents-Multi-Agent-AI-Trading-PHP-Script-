<?php
/**
 * TradingAgents PHP 8.4 — MySQL 8.x / MariaDB PDO Database Manager
 *
 * Fixed:
 * - Removed pre-query `SELECT 1` inside `connection()` which was resetting `PDO::lastInsertId()`
 *   to 0 on MariaDB/cPanel and causing FK constraint 1452 on `analysis_queue`.
 * - Added explicit `SELECT LAST_INSERT_ID()` fallback in `insert()`.
 * - Automatic connection recovery ("MySQL server has gone away" error 2006/2013) inside `query()`.
 */

declare(strict_types=1);

namespace TradingAgents;

use PDO;
use PDOException;
use PDOStatement;

final class Database
{
    private static ?PDO $pdo = null;
    private static ?array $settingsCache = null;

    public static function connection(): PDO
    {
        if (self::$pdo !== null) {
            return self::$pdo;
        }

        $dbCfg = Bootstrap::config('db');
        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $dbCfg['host'] ?? 'localhost',
            (int)($dbCfg['port'] ?? 3306),
            $dbCfg['database'] ?? '',
            $dbCfg['charset'] ?? 'utf8mb4'
        );

        self::$pdo = new PDO(
            $dsn,
            (string)($dbCfg['username'] ?? ''),
            (string)($dbCfg['password'] ?? ''),
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
            ]
        );

        return self::$pdo;
    }

    public static function query(string $sql, array $params = []): PDOStatement
    {
        try {
            $stmt = self::connection()->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            // Reconnect once if MySQL timed out during a long LLM HTTP call
            $driverCode = (int)($e->errorInfo[1] ?? 0);
            if (in_array($driverCode, [2006, 2013], true) || str_contains(strtolower($e->getMessage()), 'gone away')) {
                self::$pdo = null;
                $stmt = self::connection()->prepare($sql);
                $stmt->execute($params);
                return $stmt;
            }
            throw $e;
        }
    }

    public static function fetchAll(string $sql, array $params = []): array
    {
        return self::query($sql, $params)->fetchAll();
    }

    public static function fetchOne(string $sql, array $params = []): ?array
    {
        $row = self::query($sql, $params)->fetch();
        return $row !== false ? $row : null;
    }

    public static function fetchColumn(string $sql, array $params = [], int $col = 0): mixed
    {
        return self::query($sql, $params)->fetchColumn($col);
    }

    public static function insert(string $sql, array $params = []): int
    {
        self::query($sql, $params);
        $pdo = self::connection();
        $id = (int)$pdo->lastInsertId();
        if ($id <= 0) {
            $id = (int)self::fetchColumn("SELECT LAST_INSERT_ID()");
        }
        return $id;
    }

    public static function getSettings(bool $forceRefresh = false): array
    {
        if (self::$settingsCache !== null && !$forceRefresh) {
            return self::$settingsCache;
        }
        $rows = self::fetchAll("SELECT `setting_key`, `setting_value` FROM `system_settings`");
        $map = [];
        foreach ($rows as $r) {
            $map[$r['setting_key']] = $r['setting_value'];
        }
        self::$settingsCache = $map;
        return $map;
    }

    public static function getSetting(string $key, mixed $default = null): mixed
    {
        $all = self::getSettings();
        return array_key_exists($key, $all) && $all[$key] !== null ? $all[$key] : $default;
    }

    public static function setSetting(string $key, string $value, string $group = 'general', int $isPublic = 0): void
    {
        self::query(
            "INSERT INTO `system_settings` (`setting_key`, `setting_value`, `setting_group`, `is_public`)
             VALUES (:k, :v, :g, :p)
             ON DUPLICATE KEY UPDATE `setting_value` = VALUES(`setting_value`), `setting_group` = VALUES(`setting_group`)",
            [':k' => $key, ':v' => $value, ':g' => $group, ':p' => $isPublic]
        );
        self::$settingsCache = null;
    }
}
