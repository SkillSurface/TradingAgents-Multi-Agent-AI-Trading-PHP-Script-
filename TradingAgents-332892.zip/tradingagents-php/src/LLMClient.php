<?php
/**
 * TradingAgents PHP 8.4 — Multi-Provider LLM Client with Smart OpenRouter & Cross-Provider Routing
 *
 * Improvements:
 * - Auto-detects OpenRouter keys (`sk-or-...`) and OpenRouter base URLs (`https://openrouter.ai/api/v1`)
 *   even when the user selects `Anthropic Claude`, `OpenAI`, or `Google` as the provider dropdown!
 * - Cross-provider key resolution: If the user selects `anthropic` with model `anthropic/claude-opus-5.5`
 *   but stored their OpenRouter key under `openrouter` (or stored an OpenRouter key under `anthropic`),
 *   it automatically routes via OpenRouter's `/chat/completions` endpoint.
 * - Automatic invalid-model / 404 / 400 fallback: If a requested model ID (such as `anthropic/claude-opus-5.5`)
 *   is not yet live on OpenRouter's upstream, automatically falls back to `anthropic/claude-opus-4.1`,
 *   `anthropic/claude-sonnet-4.5`, `openrouter/auto`, and `openrouter/free` so analyses never fail!
 */

declare(strict_types=1);

namespace TradingAgents;

use RuntimeException;

final class LLMClient
{
    public static function chat(
        array $messages,
        string $tier = 'quick',
        ?string $providerOverride = null,
        ?string $modelOverride = null
    ): array {
        $provider = strtolower(trim($providerOverride ?: (string)Database::getSetting(
            $tier === 'deep' ? 'DeepThinkProvider' : 'QuickThinkProvider',
            'openrouter'
        )));
        $primaryModel = trim($modelOverride ?: (string)Database::getSetting(
            $tier === 'deep' ? 'DeepThinkModel' : 'QuickThinkModel',
            'openrouter/auto'
        ));

        $temperature  = (float)Database::getSetting('llm_temperature', '0.2');
        $maxTokens    = (int)Database::getSetting('llm_max_tokens', '4096');
        $autoFallback = (int)Database::getSetting('openrouter_auto_fallback', '1') === 1;

        // 1. Gather candidate keys for the selected provider
        $keys = ApiKeyManager::getActiveKeysForProvider($provider);

        // 2. If the model has an OpenRouter prefix (e.g. `anthropic/claude-...`, `openrouter/auto`)
        //    or no keys exist for the chosen provider, also pull OpenRouter keys (and any key with openrouter.ai base_url)
        $orKeys = ApiKeyManager::getActiveKeysForProvider('openrouter');
        $allLlmKeys = ApiKeyManager::getAllActiveLlmKeys();

        $mergedKeys = [];
        $seenIds = [];
        foreach (array_merge($keys, $orKeys, $allLlmKeys) as $kRow) {
            $kid = (int)$kRow['id'];
            if (!isset($seenIds[$kid])) {
                $seenIds[$kid] = true;
                $mergedKeys[] = $kRow;
            }
        }

        if (empty($mergedKeys)) {
            throw new RuntimeException(
                "No active LLM API key found in the vault. Please add an OpenRouter or provider API key in the 'AI API Keys & Models' tab."
            );
        }

        // Build model fallback chain
        $modelsToTry = [$primaryModel];

        // If user entered a Claude 5.x / GPT-6.x model name from the catalog that OpenRouter maps to 4.x/auto
        if (str_starts_with(strtolower($primaryModel), 'anthropic/claude-opus-5') || str_starts_with(strtolower($primaryModel), 'anthropic/claude-fable')) {
            $modelsToTry[] = 'anthropic/claude-opus-4.1';
            $modelsToTry[] = 'anthropic/claude-sonnet-4.5';
            $modelsToTry[] = 'anthropic/claude-3.7-sonnet';
        } elseif (str_starts_with(strtolower($primaryModel), 'anthropic/claude-sonnet-5') || str_starts_with(strtolower($primaryModel), 'anthropic/claude-sonnet-4.6')) {
            $modelsToTry[] = 'anthropic/claude-sonnet-4.5';
            $modelsToTry[] = 'anthropic/claude-3.7-sonnet';
        } elseif (str_starts_with(strtolower($primaryModel), 'anthropic/claude-haiku-5')) {
            $modelsToTry[] = 'anthropic/claude-haiku-4.5';
            $modelsToTry[] = 'anthropic/claude-3.5-haiku';
        } elseif (str_starts_with(strtolower($primaryModel), 'openai/gpt-6') || str_starts_with(strtolower($primaryModel), 'openai/gpt-5.')) {
            $modelsToTry[] = 'openai/gpt-4.1';
            $modelsToTry[] = 'openai/gpt-4o';
        }

        // Always include openrouter/auto and the free fallback chain when OpenRouter is used
        if ($autoFallback || ModelCatalog::isModelFree($primaryModel) || str_contains($primaryModel, '/')) {
            $modelsToTry[] = 'openrouter/auto';
            $chainCsv = (string)Database::getSetting(
                'openrouter_free_fallback_chain',
                'openrouter/free,google/gemma-3-27b-it:free,meta-llama/llama-3.3-70b-instruct:free,deepseek/deepseek-chat-v3-0324:free,qwen/qwen-2.5-72b-instruct:free'
            );
            foreach (explode(',', $chainCsv) as $cand) {
                $cand = trim($cand);
                if ($cand !== '' && !in_array($cand, $modelsToTry, true)) {
                    $modelsToTry[] = $cand;
                }
            }
        }

        $modelsToTry = array_values(array_unique($modelsToTry));
        $providersMeta = ModelCatalog::getProviders();

        $lastError = 'Unknown LLM error';
        $startTime = microtime(true);

        foreach ($modelsToTry as $modelId) {
            foreach ($mergedKeys as $keyRow) {
                $keyId    = (int)$keyRow['id'];
                $plainKey = (string)$keyRow['decrypted_key'];
                $keyProv  = strtolower((string)$keyRow['provider_slug']);
                $provMeta = $providersMeta[$keyProv] ?? $providersMeta['openrouter'];

                $baseUrl  = rtrim((string)($keyRow['base_url'] ?: ($provMeta['base_url'] ?? 'https://openrouter.ai/api/v1')), '/');
                $protocol = $provMeta['protocol'] ?? 'openai';

                // CRITICAL: If the key is an OpenRouter key (`sk-or-...`) OR the base_url is `openrouter.ai`,
                // ALWAYS use the `openai` chat/completions protocol and OpenRouter base URL!
                $isOpenRouterKey = str_starts_with($plainKey, 'sk-or-') || str_contains(strtolower($baseUrl), 'openrouter.ai') || $keyProv === 'openrouter';
                if ($isOpenRouterKey) {
                    $protocol = 'openai';
                    if (!str_contains(strtolower($baseUrl), 'openrouter.ai')) {
                        $baseUrl = 'https://openrouter.ai/api/v1';
                    }
                    $effectiveProvider = 'openrouter';
                } else {
                    $effectiveProvider = $keyProv;
                }

                // Adjust model ID if calling native Anthropic API directly (strip `anthropic/` prefix)
                $effectiveModel = $modelId;
                if ($protocol === 'anthropic' && str_starts_with($effectiveModel, 'anthropic/')) {
                    $effectiveModel = substr($effectiveModel, 10);
                }

                $res = self::dispatchRequest(
                    $protocol,
                    $effectiveProvider,
                    $baseUrl,
                    $plainKey,
                    $effectiveModel,
                    $messages,
                    $temperature,
                    $maxTokens
                );

                if ($res['ok'] && trim($res['content']) !== '') {
                    $latencyMs = (int)round((microtime(true) - $startTime) * 1000);
                    ApiKeyManager::recordSuccess($keyId, (int)$res['tokens']);
                    return [
                        'content'    => trim($res['content']),
                        'provider'   => $effectiveProvider,
                        'model'      => $res['actual_model'] ?: $effectiveModel,
                        'tokens'     => (int)$res['tokens'],
                        'latency_ms' => $latencyMs,
                    ];
                }

                $lastError = $res['error'] ?? "HTTP {$res['http_code']} from {$effectiveProvider} ({$effectiveModel})";
                // Only penalize the key if it's an auth/rate-limit error, NOT if the model name was invalid (400/404)
                if (!in_array((int)$res['http_code'], [400, 404], true)) {
                    ApiKeyManager::recordFailure($keyId, (int)$res['http_code'], $lastError);
                }
            }
        }

        Logger::log('ERROR', 'llm', "All LLM keys/models exhausted. Last error: {$lastError}");
        throw new RuntimeException("AI Model Request Failed: {$lastError}");
    }

    public static function chatStructured(
        array $messages,
        array $requiredKeys,
        string $tier = 'quick',
        ?string $providerOverride = null,
        ?string $modelOverride = null
    ): array {
        $res = self::chat($messages, $tier, $providerOverride, $modelOverride);
        $parsed = self::extractJson($res['content']);

        if (is_array($parsed)) {
            $missing = false;
            foreach ($requiredKeys as $rk) {
                if (!array_key_exists($rk, $parsed)) {
                    $missing = true;
                    break;
                }
            }
            if (!$missing) {
                $res['structured'] = $parsed;
                return $res;
            }
        }

        $res['structured'] = is_array($parsed) ? $parsed : null;
        return $res;
    }

    public static function extractJson(string $raw): ?array
    {
        $trimmed = trim($raw);
        $direct = json_decode($trimmed, true);
        if (is_array($direct)) {
            return $direct;
        }

        if (preg_match('/```(?:json)?\s*(\{.*?\})\s*```/is', $trimmed, $m)) {
            $fenced = json_decode($m[1], true);
            if (is_array($fenced)) {
                return $fenced;
            }
        }

        $firstBrace = strpos($trimmed, '{');
        $lastBrace  = strrpos($trimmed, '}');
        if ($firstBrace !== false && $lastBrace !== false && $lastBrace > $firstBrace) {
            $sub = substr($trimmed, $firstBrace, $lastBrace - $firstBrace + 1);
            $extracted = json_decode($sub, true);
            if (is_array($extracted)) {
                return $extracted;
            }
        }

        return null;
    }

    public static function testSingleKey(string $provider, string $plainKey, string $model, ?string $baseUrl = null): array
    {
        $providersMeta = ModelCatalog::getProviders();
        $meta = $providersMeta[$provider] ?? $providersMeta['openrouter'];
        $protocol = $meta['protocol'] ?? 'openai';
        $endpointBase = rtrim($baseUrl ?: ($meta['base_url'] ?? 'https://openrouter.ai/api/v1'), '/');

        // Auto-detect OpenRouter key or base URL
        if (str_starts_with($plainKey, 'sk-or-') || str_contains(strtolower($endpointBase), 'openrouter.ai')) {
            $protocol = 'openai';
            $provider = 'openrouter';
            if (!str_contains(strtolower($endpointBase), 'openrouter.ai')) {
                $endpointBase = 'https://openrouter.ai/api/v1';
            }
            $model = 'openrouter/auto';
        }

        $messages = [
            ['role' => 'user', 'content' => 'Reply with the single word READY.'],
        ];

        $res = self::dispatchRequest($protocol, $provider, $endpointBase, $plainKey, $model, $messages, 0.0, 32);
        if ($res['ok']) {
            return [
                'ok'    => true,
                'model' => $res['actual_model'] ?: $model,
                'reply' => mb_substr(trim($res['content']), 0, 80),
            ];
        }
        return [
            'ok'     => false,
            'status' => ($res['http_code'] === 429) ? 'rate_limited' : 'invalid',
            'error'  => $res['error'] ?? ('HTTP ' . $res['http_code']),
        ];
    }

    private static function dispatchRequest(
        string $protocol,
        string $provider,
        string $baseUrl,
        string $apiKey,
        string $model,
        array $messages,
        float $temperature,
        int $maxTokens
    ): array {
        $timeout = (int)Bootstrap::config('hosting.http_timeout', 28);
        $connectTimeout = (int)Bootstrap::config('hosting.connect_timeout', 10);

        if ($protocol === 'anthropic') {
            $url = $baseUrl . '/messages';
            $systemText = '';
            $anthMessages = [];
            foreach ($messages as $m) {
                if (($m['role'] ?? '') === 'system') {
                    $systemText .= ($systemText ? "\n\n" : '') . $m['content'];
                } else {
                    $anthMessages[] = [
                        'role'    => ($m['role'] === 'assistant') ? 'assistant' : 'user',
                        'content' => (string)$m['content'],
                    ];
                }
            }
            $payload = [
                'model'      => $model,
                'max_tokens' => max(256, $maxTokens),
                'messages'   => $anthMessages,
            ];
            if ($systemText !== '') {
                $payload['system'] = $systemText;
            }
            $headers = [
                'Content-Type: application/json',
                'x-api-key: ' . $apiKey,
                'anthropic-version: 2023-06-01',
            ];
        } else {
            $url = str_ends_with($baseUrl, '/chat/completions') ? $baseUrl : ($baseUrl . '/chat/completions');
            $payload = [
                'model'       => $model,
                'messages'    => $messages,
                'temperature' => $temperature,
                'max_tokens'  => max(64, $maxTokens),
            ];
            $headers = [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $apiKey,
            ];
            if ($provider === 'openrouter' || str_contains(strtolower($baseUrl), 'openrouter.ai')) {
                $siteUrl  = (string)Bootstrap::config('app.url', 'https://localhost');
                $siteName = (string)Database::getSetting('site_name', 'TradingAgents AI Platform');
                $headers[] = 'HTTP-Referer: ' . $siteUrl;
                $headers[] = 'X-Title: ' . $siteName;
            }
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => $timeout,
            CURLOPT_CONNECTTIMEOUT => $connectTimeout,
            CURLOPT_USERAGENT      => 'TradingAgentsPHP/2.0',
        ]);

        $rawBody = curl_exec($ch);
        $curlErr = curl_error($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($rawBody === false) {
            return [
                'ok'        => false,
                'http_code' => 0,
                'error'     => 'cURL transport error: ' . $curlErr,
            ];
        }

        $json = json_decode((string)$rawBody, true);
        if ($httpCode >= 200 && $httpCode < 300 && is_array($json)) {
            if ($protocol === 'anthropic') {
                $content = $json['content'][0]['text'] ?? '';
                $tokens  = (int)(($json['usage']['input_tokens'] ?? 0) + ($json['usage']['output_tokens'] ?? 0));
                $actualModel = (string)($json['model'] ?? $model);
            } else {
                $choice = $json['choices'][0]['message'] ?? [];
                $content = (string)($choice['content'] ?? '');
                if (trim($content) === '' && !empty($choice['reasoning'])) {
                    $content = (string)$choice['reasoning'];
                }
                $tokens = (int)($json['usage']['total_tokens'] ?? 0);
                $actualModel = (string)($json['model'] ?? $model);
            }

            if (trim($content) !== '') {
                return [
                    'ok'           => true,
                    'http_code'    => $httpCode,
                    'content'      => $content,
                    'actual_model' => $actualModel,
                    'tokens'       => $tokens,
                ];
            }
        }

        $errMsg = $json['error']['message']
            ?? $json['message']
            ?? (is_string($json['error'] ?? null) ? $json['error'] : null)
            ?? ('HTTP ' . $httpCode . ': ' . mb_substr((string)$rawBody, 0, 240));

        return [
            'ok'        => false,
            'http_code' => $httpCode,
            'error'     => (string)$errMsg,
        ];
    }
}
