<?php
/**
 * TradingAgents PHP 8.4 — Audit & System Logger with Automatic Secret Scrubbing
 *
 * Ensures API keys and bearer tokens are never leaked into database or file logs.
 */

declare(strict_types=1);

namespace TradingAgents;

use Throwable;

final class Logger
{
    /**
     * Scrubs potential API keys, Bearer tokens, and query-string secrets from log text.
     */
    public static function scrub(string $text): string
    {
        $patterns = [
            '/(sk-[a-zA-Z0-9\-_]{8})[a-zA-Z0-9\-_]+/i' => '$1...[REDACTED]',
            '/(Bearer\s+)[a-zA-Z0-9\-._~+\/]+=*/i'     => '$1[REDACTED]',
            '/([?&](?:api_key|apikey|key|token)=)[^&\s]+/i' => '$1[REDACTED]',
            '/(AIza[0-9A-Za-z\-_]{6})[0-9A-Za-z\-_]+/' => '$1...[REDACTED]',
            '/(xai-[0-9A-Za-z\-_]{6})[0-9A-Za-z\-_]+/' => '$1...[REDACTED]',
            '/(gsk_[0-9A-Za-z\-_]{6})[0-9A-Za-z\-_]+/' => '$1...[REDACTED]',
        ];
        return (string)preg_replace(array_keys($patterns), array_values($patterns), $text);
    }

    public static function log(
        string $level,
        string $channel,
        string $message,
        ?int $userId = null,
        ?string $ip = null,
        array $context = []
    ): void {
        $safeMsg = mb_substr(self::scrub($message), 0, 1000);
        $safeCtx = !empty($context) ? self::scrub((string)json_encode($context, JSON_UNESCAPED_SLASHES)) : null;
        $userId = $userId ?? ($_SESSION['ta_user']['id'] ?? null);
        $ip = $ip ?? ($_SERVER['REMOTE_ADDR'] ?? (php_sapi_name() === 'cli' ? '127.0.0.1' : null));

        try {
            Database::query(
                "INSERT INTO `system_logs` (`level`, `channel`, `user_id`, `ip_address`, `message`, `context_json`)
                 VALUES (:lvl, :ch, :uid, :ip, :msg, :ctx)",
                [
                    ':lvl' => strtoupper($level),
                    ':ch'  => substr($channel, 0, 48),
                    ':uid' => $userId,
                    ':ip'  => $ip,
                    ':msg' => $safeMsg,
                    ':ctx' => $safeCtx,
                ]
            );
        } catch (Throwable) {
            // Fallback to file log if DB is unreachable
            $dir = Bootstrap::config('hosting.storage_path', dirname(__DIR__) . '/storage') . '/logs';
            if (is_dir($dir)) {
                @file_put_contents(
                    $dir . '/app.log',
                    sprintf("[%s] [%s:%s] %s\n", gmdate('c'), $level, $channel, $safeMsg),
                    FILE_APPEND
                );
            }
        }
    }
}
