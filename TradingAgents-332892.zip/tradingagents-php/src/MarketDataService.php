<?php
/**
 * TradingAgents PHP 8.4 — Real Market Data & Financial Vendors Engine
 *
 * Zero Demo / Zero Mock Data — Connects directly to real public & API sources:
 * 1. Yahoo Finance v8 Chart (`query1.finance.yahoo.com` & `query2` failover) for OHLCV & quote metadata
 * 2. SEC EDGAR XBRL Company Facts (`data.sec.gov/api/xbrl/companyfacts`) for point-in-time US Balance Sheet,
 *    Income Statement, and Cash Flow filings + Yahoo/Alpha Vantage Fundamentals
 * 3. Yahoo Finance RSS + Google News RSS for ticker & global macro news headlines
 * 4. StockTwits public JSON symbol stream (`api.stocktwits.com`) with Bullish/Bearish retail ratio
 * 5. Reddit Atom/RSS search feed (`www.reddit.com/r/wallstreetbets+stocks+investing/search.rss`)
 * 6. Polymarket Gamma API (`gamma-api.polymarket.com`) for live forward event probabilities
 * 7. FRED (`api.stlouisfed.org/fred`) for macroeconomic series (CPI, Fed Funds, 10Y Treasury, Yield Curve, Unemployment, VIX)
 */

declare(strict_types=1);

namespace TradingAgents;

use Throwable;

final class MarketDataService
{
    private const BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
    private const TA_UA      = 'tradingagents-php/2.0 (+https://github.com/TauricResearch/TradingAgents)';

    /**
     * Resolves deterministic instrument identity & metadata from Yahoo Finance + SEC EDGAR.
     */
    public static function resolveInstrumentContext(string $ticker, string $tradeDate): array
    {
        $cleanTicker = Security::cleanTicker($ticker);
        $cacheKey = "identity_{$cleanTicker}_{$tradeDate}";
        $cached = Cache::get($cacheKey);
        if (is_array($cached) && !empty($cached['ticker'])) {
            return $cached;
        }

        $ohlcvData = self::getOhlcvAndQuote($cleanTicker, $tradeDate);
        $meta = $ohlcvData['meta'] ?? [];

        $companyName = $meta['longName'] ?? $meta['shortName'] ?? $cleanTicker;
        $currency    = $meta['currency'] ?? 'USD';
        $exchange    = $meta['exchangeName'] ?? $meta['fullExchangeName'] ?? 'Market';
        $instType    = strtolower((string)($meta['instrumentType'] ?? 'EQUITY'));

        $assetType = 'stock';
        if (str_contains($instType, 'crypto') || str_ends_with($cleanTicker, '-USD')) {
            $assetType = 'crypto';
        } elseif (str_contains($instType, 'etf')) {
            $assetType = 'etf';
        } elseif (str_starts_with($cleanTicker, '^')) {
            $assetType = 'index';
        }

        $latestClose = $ohlcvData['latest']['close'] ?? ($meta['regularMarketPrice'] ?? null);

        $contextText = sprintf(
            "Instrument Identity: **%s** (%s) | Exchange: %s | Currency: %s | Asset Class: %s | Analysis Date: %s | Latest Verified Close: %s %s",
            $companyName,
            $cleanTicker,
            $exchange,
            $currency,
            strtoupper($assetType),
            $tradeDate,
            $latestClose !== null ? (string)$latestClose : 'N/A',
            $currency
        );

        $result = [
            'ticker'       => $cleanTicker,
            'company_name' => (string)$companyName,
            'currency'     => (string)$currency,
            'exchange'     => (string)$exchange,
            'asset_type'   => $assetType,
            'latest_price' => $latestClose !== null ? (float)$latestClose : null,
            'context_text' => $contextText,
        ];

        Cache::set($cacheKey, $result, 3600, 'snapshot', $cleanTicker);
        return $result;
    }

    /**
     * Fetches daily OHLCV bars up to `$tradeDate` (look-ahead safe) and computes all technical indicators.
     */
    public static function getOhlcvAndQuote(string $ticker, string $tradeDate): array
    {
        $cleanTicker = Security::cleanTicker($ticker);
        $ttl = (int)Database::getSetting('cache_ttl_ohlcv', '900');
        $cacheKey = "ohlcv_{$cleanTicker}_{$tradeDate}";
        $cached = Cache::get($cacheKey);
        if (is_array($cached) && !empty($cached['bars'])) {
            return $cached;
        }

        $endTs   = strtotime($tradeDate . ' 23:59:59 UTC') ?: time();
        $startTs = $endTs - (400 * 86400); // ~400 calendar days (~275 trading sessions for 200 SMA)

        $hosts = ['https://query1.finance.yahoo.com', 'https://query2.finance.yahoo.com'];
        $bars  = [];
        $meta  = [];

        foreach ($hosts as $host) {
            $url = sprintf(
                '%s/v8/finance/chart/%s?period1=%d&period2=%d&interval=1d&includePrePost=false&events=div%%2Csplits',
                $host,
                 rawurlencode($cleanTicker),
                $startTs,
                $endTs
            );
            $res = self::httpGet($url, ['User-Agent: ' . self::BROWSER_UA]);
            if ($res['http_code'] === 200) {
                $json = json_decode($res['body'], true);
                $resultNode = $json['chart']['result'][0] ?? null;
                if (is_array($resultNode)) {
                    $meta = $resultNode['meta'] ?? [];
                    $timestamps = $resultNode['timestamp'] ?? [];
                    $quote = $resultNode['indicators']['quote'][0] ?? [];
                    foreach ($timestamps as $idx => $ts) {
                        $c = $quote['close'][$idx] ?? null;
                        $o = $quote['open'][$idx] ?? $c;
                        $h = $quote['high'][$idx] ?? $c;
                        $l = $quote['low'][$idx] ?? $c;
                        $v = $quote['volume'][$idx] ?? 0;
                        if ($c === null || $c <= 0) {
                            continue;
                        }
                        $barDate = gmdate('Y-m-d', (int)$ts);
                        if ($barDate <= $tradeDate) {
                            $bars[$barDate] = [
                                'date'   => $barDate,
                                'open'   => (float)$o,
                                'high'   => (float)$h,
                                'low'    => (float)$l,
                                'close'  => (float)$c,
                                'volume' => (float)$v,
                            ];
                        }
                    }
                    if (!empty($bars)) {
                        break;
                    }
                }
            }
        }

        // Alpha Vantage fallback if Yahoo was blocked or empty
        if (empty($bars)) {
            $avKey = ApiKeyManager::getVendorKey('alphavantage');
            if ($avKey) {
                $avUrl = 'https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&outputsize=compact&symbol='
                    . urlencode($cleanTicker) . '&apikey=' . urlencode($avKey);
                $res = self::httpGet($avUrl);
                $json = json_decode($res['body'], true);
                $series = $json['Time Series (Daily)'] ?? [];
                ksort($series);
                foreach ($series as $d => $row) {
                    if ($d <= $tradeDate) {
                        $bars[$d] = [
                            'date'   => $d,
                            'open'   => (float)($row['1. open'] ?? 0),
                            'high'   => (float)($row['2. high'] ?? 0),
                            'low'    => (float)($row['3. low'] ?? 0),
                            'close'  => (float)($row['4. close'] ?? 0),
                            'volume' => (float)($row['5. volume'] ?? 0),
                        ];
                    }
                }
            }
        }

        ksort($bars);
        $orderedBars = array_values($bars);
        $indicators  = TechnicalIndicators::computeAll($orderedBars);

        $payload = [
            'ticker'           => $cleanTicker,
            'meta'             => $meta,
            'bars'             => $orderedBars,
            'latest'           => $indicators['latest'],
            'summary_markdown' => $indicators['summary_markdown'],
        ];

        if (!empty($orderedBars)) {
            Cache::set($cacheKey, $payload, $ttl, 'ohlcv', $cleanTicker);
        }
        return $payload;
    }

    /**
     * Fetches comprehensive Fundamentals: SEC EDGAR XBRL filings (as of `$tradeDate`) + Yahoo/Alpha Vantage overview.
     */
    public static function getFundamentalsReportData(string $ticker, string $tradeDate): string
    {
        $cleanTicker = Security::cleanTicker($ticker);
        $ttl = (int)Database::getSetting('cache_ttl_fundamentals', '43200');
        $cacheKey = "fundamentals_{$cleanTicker}_{$tradeDate}";
        $cached = Cache::get($cacheKey);
        if (is_string($cached) && $cached !== '') {
            return $cached;
        }

        $sections = [];

        // 1. SEC EDGAR Point-in-Time XBRL Statements (Balance Sheet, Income Statement, Cash Flow)
        $edgarMd = self::fetchSecEdgarStatements($cleanTicker, $tradeDate);
        if ($edgarMd !== '') {
            $sections[] = $edgarMd;
        }

        // 2. Alpha Vantage Company Overview if key is configured
        $avKey = ApiKeyManager::getVendorKey('alphavantage');
        if ($avKey) {
            $avUrl = 'https://www.alphavantage.co/query?function=OVERVIEW&symbol=' . urlencode($cleanTicker) . '&apikey=' . urlencode($avKey);
            $res = self::httpGet($avUrl);
            $ov = json_decode($res['body'], true);
            if (is_array($ov) && !empty($ov['Symbol'])) {
                $sections[] = "### Company Overview & Valuation Ratios (Alpha Vantage)\n"
                    . "- **Name**: " . ($ov['Name'] ?? $cleanTicker) . " | **Sector**: " . ($ov['Sector'] ?? 'N/A') . " | **Industry**: " . ($ov['Industry'] ?? 'N/A') . "\n"
                    . "- **Market Cap**: $" . number_format((float)($ov['MarketCapitalization'] ?? 0)) . "\n"
                    . "- **P/E Ratio (TTM)**: " . ($ov['PERatio'] ?? 'N/A') . " | **Forward P/E**: " . ($ov['ForwardPE'] ?? 'N/A') . " | **PEG Ratio**: " . ($ov['PEGRatio'] ?? 'N/A') . "\n"
                    . "- **Price/Book**: " . ($ov['PriceToBookRatio'] ?? 'N/A') . " | **EV/EBITDA**: " . ($ov['EVToEBITDA'] ?? 'N/A') . "\n"
                    . "- **EPS (TTM)**: " . ($ov['EPS'] ?? 'N/A') . " | **Profit Margin**: " . ($ov['ProfitMargin'] ?? 'N/A') . " | **Operating Margin**: " . ($ov['OperatingMarginTTM'] ?? 'N/A') . "\n"
                    . "- **Return on Equity (ROE)**: " . ($ov['ReturnOnEquityTTM'] ?? 'N/A') . " | **Return on Assets (ROA)**: " . ($ov['ReturnOnAssetsTTM'] ?? 'N/A') . "\n"
                    . "- **Revenue (TTM)**: $" . number_format((float)($ov['RevenueTTM'] ?? 0)) . " | **Gross Profit (TTM)**: $" . number_format((float)($ov['GrossProfitTTM'] ?? 0)) . "\n"
                    . "- **52-Week High / Low**: " . ($ov['52WeekHigh'] ?? 'N/A') . " / " . ($ov['52WeekLow'] ?? 'N/A') . " | **Beta**: " . ($ov['Beta'] ?? 'N/A') . "\n"
                    . "- **Analyst Target Price**: " . ($ov['AnalystTargetPrice'] ?? 'N/A') . "\n"
                    . "- **Business Description**: " . ($ov['Description'] ?? 'N/A');
            }
        }

        // 3. Yahoo Finance Chart Metadata & Price Valuation Snapshot
        $ohlcv = self::getOhlcvAndQuote($cleanTicker, $tradeDate);
        $meta  = $ohlcv['meta'] ?? [];
        $lat   = $ohlcv['latest'] ?? [];
        if (!empty($meta) || !empty($lat)) {
            $sections[] = "### Market Valuation & Trading Profile (Yahoo Finance)\n"
                . "- **Instrument**: " . ($meta['longName'] ?? $meta['shortName'] ?? $cleanTicker) . " (`{$cleanTicker}`)\n"
                . "- **Exchange**: " . ($meta['fullExchangeName'] ?? $meta['exchangeName'] ?? 'N/A') . " | **Currency**: " . ($meta['currency'] ?? 'USD') . "\n"
                . "- **Latest Close (as of {$tradeDate})**: " . ($lat['close'] ?? $meta['regularMarketPrice'] ?? 'N/A') . "\n"
                . "- **52-Week High**: " . ($meta['fiftyTwoWeekHigh'] ?? $lat['high_52w'] ?? 'N/A') . " | **52-Week Low**: " . ($meta['fiftyTwoWeekLow'] ?? $lat['low_52w'] ?? 'N/A') . "\n"
                . "- **50-Day SMA**: " . ($lat['close_50_sma'] ?? 'N/A') . " | **200-Day SMA**: " . ($lat['close_200_sma'] ?? 'N/A');
        }

        $combined = !empty($sections)
            ? implode("\n\n", $sections)
            : "Fundamental filings for {$cleanTicker} as of {$tradeDate}: Non-US or crypto instrument without SEC EDGAR CIK; evaluate based on market structure and price metrics.";

        Cache::set($cacheKey, $combined, $ttl, 'fundamentals', $cleanTicker);
        return $combined;
    }

    /**
     * Fetches authentic SEC EDGAR XBRL Company Facts (`data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json`)
     * filtered strictly to filings submitted on or before `$tradeDate` (point-in-time safe, matching `sec_edgar.py`).
     */
    public static function fetchSecEdgarStatements(string $ticker, string $tradeDate): string
    {
        $secUa = (string)Database::getSetting('sec_edgar_user_agent', 'TradingAgentsPHP/2.0 (admin@yourdomain.com)');
        $cik = self::resolveSecCik($ticker, $secUa);
        if ($cik === null) {
            return '';
        }

        $paddedCik = str_pad($cik, 10, '0', STR_PAD_LEFT);
        $cacheKey  = "sec_edgar_facts_{$paddedCik}";
        $factsJson = Cache::get($cacheKey);

        if (!is_array($factsJson)) {
            $url = "https://data.sec.gov/api/xbrl/companyfacts/CIK{$paddedCik}.json";
            $res = self::httpGet($url, ['User-Agent: ' . $secUa, 'Accept: application/json']);
            if ($res['http_code'] !== 200) {
                return '';
            }
            $factsJson = json_decode($res['body'], true);
            if (is_array($factsJson)) {
                Cache::set($cacheKey, $factsJson, 86400, 'sec_edgar', $ticker);
            }
        }

        $usGaap = $factsJson['facts']['us-gaap'] ?? [];
        if (empty($usGaap)) {
            return '';
        }

        $entityName = $factsJson['entityName'] ?? $ticker;

        // Exact line-item tag priority from TradingAgents `sec_edgar.py`
        $statementDefs = [
            'Balance Sheet (SEC EDGAR XBRL)' => [
                'Total Assets'             => ['Assets'],
                'Current Assets'           => ['AssetsCurrent'],
                'Cash & Equivalents'       => ['CashAndCashEquivalentsAtCarryingValue'],
                'Total Liabilities'        => ['Liabilities'],
                'Current Liabilities'      => ['LiabilitiesCurrent'],
                'Stockholders Equity'      => ['StockholdersEquity', 'StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest'],
            ],
            'Income Statement (SEC EDGAR XBRL)' => [
                'Revenue'                  => ['RevenueFromContractWithCustomerExcludingAssessedTax', 'Revenues', 'SalesRevenueNet'],
                'Cost of Revenue'          => ['CostOfRevenue', 'CostOfGoodsAndServicesSold'],
                'Gross Profit'             => ['GrossProfit'],
                'Operating Income'         => ['OperatingIncomeLoss'],
                'Net Income'               => ['NetIncomeLoss'],
                'Diluted EPS'              => ['EarningsPerShareDiluted'],
            ],
            'Cash Flow Statement (SEC EDGAR XBRL)' => [
                'Operating Cash Flow'      => ['NetCashProvidedByUsedInOperatingActivities', 'NetCashProvidedByUsedInOperatingActivitiesContinuingOperations'],
                'Investing Cash Flow'      => ['NetCashProvidedByUsedInInvestingActivities'],
                'Financing Cash Flow'      => ['NetCashProvidedByUsedInFinancingActivities'],
                'Capital Expenditure'      => ['PaymentsToAcquirePropertyPlantAndEquipment', 'PaymentsToAcquireProductiveAssets'],
            ],
        ];

        $out = ["### SEC EDGAR Official XBRL Filings — {$entityName} (CIK {$paddedCik}, Filed ≤ {$tradeDate})"];

        foreach ($statementDefs as $sectionTitle => $items) {
            $out[] = "#### {$sectionTitle}";
            $out[] = "| Line Item | Latest Reported Value | Period End | Form | Filed Date |";
            $out[] = "| :--- | ---: | :--- | :--- | :--- |";

            foreach ($items as $label => $tags) {
                $bestEntry = null;
                foreach ($tags as $tag) {
                    if (empty($usGaap[$tag]['units'])) {
                        continue;
                    }
                    foreach ($usGaap[$tag]['units'] as $unitName => $entries) {
                        foreach ($entries as $entry) {
                            $filed = $entry['filed'] ?? '';
                            $end   = $entry['end'] ?? '';
                            $form  = $entry['form'] ?? '';
                            if ($filed === '' || $filed > $tradeDate) {
                                continue;
                            }
                            if (!in_array($form, ['10-K', '10-Q', '20-F', '40-F'], true)) {
                                continue;
                            }
                            if ($bestEntry === null || $end > $bestEntry['end'] || ($end === $bestEntry['end'] && $filed > $bestEntry['filed'])) {
                                $bestEntry = [
                                    'val'   => $entry['val'],
                                    'unit'  => $unitName,
                                    'end'   => $end,
                                    'form'  => $form,
                                    'filed' => $filed,
                                ];
                            }
                        }
                    }
                    if ($bestEntry !== null) {
                        break;
                    }
                }

                if ($bestEntry !== null) {
                    $valFormatted = ($bestEntry['unit'] === 'USD' && abs((float)$bestEntry['val']) >= 1000000)
                        ? '$' . number_format((float)$bestEntry['val'] / 1000000, 2) . 'M'
                        : $bestEntry['val'] . ' ' . $bestEntry['unit'];
                    $out[] = "| {$label} | **{$valFormatted}** | {$bestEntry['end']} | {$bestEntry['form']} | {$bestEntry['filed']} |";
                }
            }
            $out[] = "";
        }

        return implode("\n", $out);
    }

    private static function resolveSecCik(string $ticker, string $secUa): ?string
    {
        $map = Cache::get('sec_edgar_company_tickers_map');
        if (!is_array($map)) {
            $res = self::httpGet('https://www.sec.gov/files/company_tickers.json', [
                'User-Agent: ' . $secUa,
                'Accept: application/json',
            ]);
            if ($res['http_code'] === 200) {
                $raw = json_decode($res['body'], true);
                if (is_array($raw)) {
                    $map = [];
                    foreach ($raw as $item) {
                        if (!empty($item['ticker']) && isset($item['cik_str'])) {
                            $map[strtoupper((string)$item['ticker'])] = (string)$item['cik_str'];
                        }
                    }
                    Cache::set('sec_edgar_company_tickers_map', $map, 86400 * 7, 'sec_edgar');
                }
            }
        }
        $normalized = strtoupper(str_replace('.', '-', $ticker));
        return $map[$normalized] ?? $map[strtoupper($ticker)] ?? null;
    }

    /**
     * Fetches Ticker News + Global Macro News + FRED Macro Series + Polymarket Implied Odds
     * for the News Analyst & Sentiment Analyst.
     */
    public static function getNewsAndMacroBundle(string $ticker, string $tradeDate): array
    {
        $cleanTicker = Security::cleanTicker($ticker);
        $ttl = (int)Database::getSetting('cache_ttl_news', '1800');
        $cacheKey = "news_bundle_{$cleanTicker}_{$tradeDate}";
        $cached = Cache::get($cacheKey);
        if (is_array($cached) && isset($cached['ticker_news'])) {
            return $cached;
        }

        $tickerNews = self::fetchYahooRssNews($cleanTicker, 15);
        $macroNews  = self::fetchGlobalMacroNews(10);
        $polymarket = self::fetchPolymarketOdds(6);
        $fredMacro  = self::fetchFredIndicators($tradeDate);

        $bundle = [
            'ticker_news' => $tickerNews,
            'macro_news'  => $macroNews,
            'polymarket'  => $polymarket,
            'fred_macro'  => $fredMacro,
        ];

        Cache::set($cacheKey, $bundle, $ttl, 'news', $cleanTicker);
        return $bundle;
    }

    /**
     * Fetches StockTwits cashtag stream + Reddit subreddit discussions for the Sentiment Analyst.
     */
    public static function getSocialSentimentBundle(string $ticker, string $tradeDate): array
    {
        $cleanTicker = Security::cleanTicker($ticker);
        $cacheKey = "social_bundle_{$cleanTicker}_{$tradeDate}";
        $cached = Cache::get($cacheKey);
        if (is_array($cached) && isset($cached['stocktwits'])) {
            return $cached;
        }

        $stocktwits = self::fetchStockTwits($cleanTicker, 25);
        $reddit     = self::fetchRedditPosts($cleanTicker, 15);

        $bundle = [
            'stocktwits' => $stocktwits,
            'reddit'     => $reddit,
        ];

        Cache::set($cacheKey, $bundle, 1800, 'stocktwits', $cleanTicker);
        return $bundle;
    }

    public static function fetchYahooRssNews(string $ticker, int $limit = 15): string
    {
        $url = 'https://feeds.finance.yahoo.com/rss/2.0/headline?s=' . rawurlencode($ticker) . '&region=US&lang=en-US';
        $res = self::httpGet($url, ['User-Agent: ' . self::TA_UA]);
        $items = [];

        if ($res['http_code'] === 200 && str_contains($res['body'], '<item>')) {
            try {
                $xml = @simplexml_load_string($res['body']);
                if ($xml && isset($xml->channel->item)) {
                    foreach ($xml->channel->item as $item) {
                        $title = trim((string)$item->title);
                        $pub   = trim((string)$item->pubDate);
                        $desc  = trim(strip_tags((string)$item->description));
                        $link  = trim((string)$item->link);
                        $items[] = "- **[{$title}]({$link})** ({$pub})\n  " . mb_substr($desc, 0, 240);
                        if (count($items) >= $limit) {
                            break;
                        }
                    }
                }
            } catch (Throwable) {
            }
        }

        // Fallback to Google News RSS for ticker if Yahoo RSS is empty
        if (empty($items)) {
            $gUrl = 'https://news.google.com/rss/search?q=' . rawurlencode($ticker . ' stock finance') . '&hl=en-US&gl=US&ceid=US:en';
            $gRes = self::httpGet($gUrl, ['User-Agent: ' . self::TA_UA]);
            if ($gRes['http_code'] === 200) {
                try {
                    $xml = @simplexml_load_string($gRes['body']);
                    if ($xml && isset($xml->channel->item)) {
                        foreach ($xml->channel->item as $item) {
                            $title = trim((string)$item->title);
                            $pub   = trim((string)$item->pubDate);
                            $link  = trim((string)$item->link);
                            $items[] = "- **[{$title}]({$link})** ({$pub})";
                            if (count($items) >= $limit) {
                                break;
                            }
                        }
                    }
                } catch (Throwable) {
                }
            }
        }

        return !empty($items) ? implode("\n", $items) : "No recent RSS headlines returned for {$ticker}.";
    }

    public static function fetchGlobalMacroNews(int $limit = 10): string
    {
        $url = 'https://news.google.com/rss/search?q=' . rawurlencode('Federal Reserve OR S&P 500 earnings OR inflation OR Treasury yields') . '&hl=en-US&gl=US&ceid=US:en';
        $res = self::httpGet($url, ['User-Agent: ' . self::TA_UA]);
        $items = [];
        if ($res['http_code'] === 200) {
            try {
                $xml = @simplexml_load_string($res['body']);
                if ($xml && isset($xml->channel->item)) {
                    foreach ($xml->channel->item as $item) {
                        $title = trim((string)$item->title);
                        $pub   = trim((string)$item->pubDate);
                        $link  = trim((string)$item->link);
                        $items[] = "- **[{$title}]({$link})** ({$pub})";
                        if (count($items) >= $limit) {
                            break;
                        }
                    }
                }
            } catch (Throwable) {
            }
        }
        return !empty($items) ? implode("\n", $items) : 'Macro news feed temporarily unavailable.';
    }

    /**
     * Fetches StockTwits public symbol stream (`api.stocktwits.com/api/2/streams/symbol/{symbol}.json`),
     * matching `tradingagents/dataflows/vendors/stocktwits.py`.
     */
    public static function fetchStockTwits(string $ticker, int $limit = 25): string
    {
        $stSymbol = str_ends_with($ticker, '-USD') ? substr($ticker, 0, -4) . '.X' : $ticker;
        $url = 'https://api.stocktwits.com/api/2/streams/symbol/' . rawurlencode($stSymbol) . '.json';
        $res = self::httpGet($url, ['User-Agent: ' . self::TA_UA, 'Accept: application/json']);

        if ($res['http_code'] !== 200) {
            return "<unavailable: StockTwits returned HTTP {$res['http_code']}>";
        }

        $json = json_decode($res['body'], true);
        $messages = $json['messages'] ?? [];
        if (empty($messages)) {
            return "No recent StockTwits messages for {$stSymbol}.";
        }

        $bullish = 0;
        $bearish = 0;
        $lines   = [];

        foreach (array_slice($messages, 0, $limit) as $m) {
            $sentiment = $m['entities']['sentiment']['basic'] ?? 'Unlabeled';
            if ($sentiment === 'Bullish') {
                $bullish++;
            } elseif ($sentiment === 'Bearish') {
                $bearish++;
            }
            $body = html_entity_decode((string)($m['body'] ?? ''), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $body = preg_replace('/\s+/', ' ', trim($body));
            $createdAt = $m['created_at'] ?? '';
            $user = $m['user']['username'] ?? 'user';
            $lines[] = "- [{$sentiment}] @{$user} ({$createdAt}): " . mb_substr((string)$body, 0, 220);
        }

        $taggedTotal = $bullish + $bearish;
        $ratioStr = $taggedTotal > 0
            ? sprintf('Bullish: %d (%.0f%%) | Bearish: %d (%.0f%%) out of %d tagged messages', $bullish, ($bullish / $taggedTotal) * 100, $bearish, ($bearish / $taggedTotal) * 100, $taggedTotal)
            : 'No Bullish/Bearish user tags in sample';

        return "**StockTwits Summary ({$stSymbol})**: {$ratioStr}\n" . implode("\n", $lines);
    }

    /**
     * Fetches Reddit public Atom/RSS search feed across r/wallstreetbets, r/stocks, r/investing,
     * matching `tradingagents/dataflows/vendors/reddit.py`.
     */
    public static function fetchRedditPosts(string $ticker, int $limit = 15): string
    {
        $subs = str_ends_with($ticker, '-USD') ? 'CryptoCurrency+CryptoMarkets+Bitcoin' : 'wallstreetbets+stocks+investing';
        $url  = "https://www.reddit.com/r/{$subs}/search.rss?q=" . rawurlencode($ticker) . "&restrict_sr=on&sort=new&t=week&limit={$limit}";
        $res  = self::httpGet($url, ['User-Agent: ' . self::TA_UA]);

        if ($res['http_code'] !== 200) {
            return "<unavailable: Reddit RSS returned HTTP {$res['http_code']}>";
        }

        $posts = [];
        try {
            $xml = @simplexml_load_string($res['body']);
            if ($xml && isset($xml->entry)) {
                foreach ($xml->entry as $entry) {
                    $title   = trim((string)$entry->title);
                    $updated = trim((string)$entry->updated);
                    $content = trim(strip_tags(html_entity_decode((string)$entry->content, ENT_QUOTES | ENT_HTML5, 'UTF-8')));
                    $content = preg_replace('/\s+/', ' ', $content);
                    $posts[] = "- **{$title}** ({$updated}): " . mb_substr((string)$content, 0, 240);
                    if (count($posts) >= $limit) {
                        break;
                    }
                }
            }
        } catch (Throwable) {
        }

        return !empty($posts) ? implode("\n", $posts) : "No recent Reddit discussions in r/{$subs} for {$ticker} over the past 7 days.";
    }

    /**
     * Fetches live prediction-market implied probabilities from Polymarket Gamma API
     * (`gamma-api.polymarket.com`), matching `tradingagents/dataflows/vendors/polymarket.py`.
     */
    public static function fetchPolymarketOdds(int $limit = 6): string
    {
        $url = "https://gamma-api.polymarket.com/events?closed=false&active=true&limit=15&order=volume&ascending=false";
        $res = self::httpGet($url, ['User-Agent: ' . self::TA_UA, 'Accept: application/json']);
        if ($res['http_code'] !== 200) {
            return 'Polymarket Gamma API unavailable.';
        }

        $events = json_decode($res['body'], true);
        if (!is_array($events)) {
            return 'No active Polymarket contracts returned.';
        }

        $lines = [];
        foreach ($events as $ev) {
            $title = $ev['title'] ?? '';
            $markets = $ev['markets'] ?? [];
            if ($title === '' || empty($markets)) {
                continue;
            }
            $m0 = $markets[0];
            $outcomes = is_string($m0['outcomes'] ?? null) ? json_decode($m0['outcomes'], true) : ($m0['outcomes'] ?? []);
            $prices   = is_string($m0['outcomePrices'] ?? null) ? json_decode($m0['outcomePrices'], true) : ($m0['outcomePrices'] ?? []);
            if (!is_array($outcomes) || !is_array($prices) || empty($outcomes)) {
                continue;
            }
            $oddsPairs = [];
            foreach ($outcomes as $idx => $outLabel) {
                $p = isset($prices[$idx]) ? round(((float)$prices[$idx]) * 100, 1) : null;
                if ($p !== null) {
                    $oddsPairs[] = "{$outLabel}: {$p}%";
                }
            }
            $vol = isset($ev['volume']) ? '$' . number_format((float)$ev['volume'], 0) : 'N/A';
            $lines[] = "- **{$title}** — Implied Odds: " . implode(', ', $oddsPairs) . " (Volume: {$vol})";
            if (count($lines) >= $limit) {
                break;
            }
        }

        return !empty($lines) ? implode("\n", $lines) : 'No forward-looking Polymarket contracts matched.';
    }

    /**
     * Fetches macroeconomic indicators from FRED (`api.stlouisfed.org/fred`) if a FRED API key is configured.
     */
    public static function fetchFredIndicators(string $tradeDate): string
    {
        $fredKey = ApiKeyManager::getVendorKey('fred');
        if (!$fredKey) {
            return 'FRED API key not configured (optional: add a free FRED key in the AI & Data API Keys Vault to include live St. Louis Fed series).';
        }

        $seriesList = [
            'FEDFUNDS' => 'Effective Federal Funds Rate (%)',
            'DGS10'    => '10-Year Treasury Constant Maturity Yield (%)',
            'T10Y2Y'   => '10Y-2Y Treasury Yield Curve Spread (%)',
            'CPIAUCSL' => 'Consumer Price Index (CPI All Urban)',
            'UNRATE'   => 'US Civilian Unemployment Rate (%)',
            'VIXCLS'   => 'CBOE Volatility Index (VIX)',
        ];

        $rows = [
            "| Series ID | Macroeconomic Indicator | Latest Value | Observation Date |",
            "| :--- | :--- | ---: | :--- |",
        ];

        foreach ($seriesList as $seriesId => $label) {
            $url = sprintf(
                'https://api.stlouisfed.org/fred/series/observations?series_id=%s&observation_end=%s&sort_order=desc&limit=5&file_type=json&api_key=%s',
                urlencode($seriesId),
                urlencode($tradeDate),
                urlencode($fredKey)
            );
            $res = self::httpGet($url);
            if ($res['http_code'] === 200) {
                $json = json_decode($res['body'], true);
                foreach (($json['observations'] ?? []) as $obs) {
                    if (isset($obs['value']) && $obs['value'] !== '.') {
                        $rows[] = "| `{$seriesId}` | {$label} | **{$obs['value']}** | {$obs['date']} |";
                        break;
                    }
                }
            }
        }

        return implode("\n", $rows);
    }

    private static function httpGet(string $url, array $headers = []): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => (int)Bootstrap::config('hosting.http_timeout', 25),
            CURLOPT_CONNECTTIMEOUT => (int)Bootstrap::config('hosting.connect_timeout', 8),
            CURLOPT_HTTPHEADER     => $headers ?: ['User-Agent: ' . self::TA_UA],
            CURLOPT_ENCODING       => '', // Accept gzip/deflate
        ]);
        $body = (string)curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return ['http_code' => $code, 'body' => $body];
    }
}
