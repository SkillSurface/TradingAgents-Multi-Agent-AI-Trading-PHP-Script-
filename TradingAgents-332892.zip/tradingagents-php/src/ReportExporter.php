<?php
/**
 * TradingAgents PHP 8.4 — Self-Contained HTML & Print-Ready PDF Report Exporter
 *
 * Faithful PHP port of `tradingagents/report_html.py` (#1419):
 * - Self-contained HTML page with inline Tauric Research SVG logo, dark/light responsive typography,
 *   interactive floating section rail, and `@media print` PDF stylesheet.
 * - Converts Agent Markdown (headings, tables, bold, lists, blockquotes, code blocks) into clean,
 *   XSS-escaped HTML without external JS dependencies.
 */

declare(strict_types=1);

namespace TradingAgents;

final class ReportExporter
{
    private const LOGO_SVG = '<svg viewBox="0 0 180 36" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="4" width="28" height="28" rx="6" fill="#087a59"/><path d="M9 12H23M16 12V25M11 20L16 15L21 20" stroke="#ffffff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/><text x="38" y="24" fill="currentColor" font-family="system-ui, -apple-system, sans-serif" font-weight="700" font-size="18" letter-spacing="-0.02em">TradingAgents AI</text></svg>';

    /**
     * Renders a complete, self-contained HTML/PDF report for an analysis run.
     */
    public static function renderHtmlReport(array $analysis, array $reports, bool $autoPrintPdf = false): string
    {
        $ticker = htmlspecialchars((string)$analysis['ticker'], ENT_QUOTES, 'UTF-8');
        $company = htmlspecialchars((string)($analysis['company_name'] ?: $analysis['ticker']), ENT_QUOTES, 'UTF-8');
        $date   = htmlspecialchars((string)$analysis['trade_date'], ENT_QUOTES, 'UTF-8');
        $rating = (string)($analysis['final_rating'] ?: 'REVIEW');
        $ratingEsc = htmlspecialchars($rating, ENT_QUOTES, 'UTF-8');

        $toneMap = [
            'Buy'         => 'up',
            'Overweight'  => 'up',
            'Hold'        => 'level',
            'Underweight' => 'down',
            'Sell'        => 'down',
        ];
        $tone = $toneMap[$rating] ?? 'review';

        // Group reports into the 5 canonical TradingAgents sections
        $groups = [
            '1. Analyst Team Reports'       => [],
            '2. Research Debate & Plan'     => [],
            '3. Trader Transaction Proposal'=> [],
            '4. Risk Management Committee'  => [],
            '5. Portfolio Manager Decision' => [],
        ];

        foreach ($reports as $r) {
            $grp = $r['stage_group'] ?? 'analyst_team';
            match ($grp) {
                'analyst_team'      => $groups['1. Analyst Team Reports'][] = $r,
                'research_debate'   => $groups['2. Research Debate & Plan'][] = $r,
                'trader_desk'       => $groups['3. Trader Transaction Proposal'][] = $r,
                'risk_committee'    => $groups['4. Risk Management Committee'][] = $r,
                'portfolio_manager' => $groups['5. Portfolio Manager Decision'][] = $r,
                default             => $groups['1. Analyst Team Reports'][] = $r,
            };
        }

        $tocItems = [];
        $bodySections = [];
        $secNum = 0;

        foreach ($groups as $heading => $items) {
            if (empty($items)) {
                continue;
            }
            $secNum++;
            [$numeral, $secName] = explode('. ', $heading, 2);
            $subLinks = [];
            $secHtml  = "<section id=\"s{$secNum}\"><h2>" . htmlspecialchars($heading, ENT_QUOTES) . "</h2>\n";

            foreach ($items as $idx => $rep) {
                $m = $idx + 1;
                $role = htmlspecialchars((string)$rep['agent_role'], ENT_QUOTES);
                $modelBadge = !empty($rep['model_used'])
                    ? ' <span class="field">' . htmlspecialchars((string)$rep['provider_used'] . ': ' . (string)$rep['model_used'], ENT_QUOTES) . '</span>'
                    : '';
                $subLinks[] = "<li><a href=\"#s{$secNum}-{$m}\"><span class=\"bar\"></span> <span class=\"label\">{$role}</span></a></li>";
                $renderedMd = self::markdownToHtml((string)$rep['report_markdown']);
                $secHtml .= "<h3 id=\"s{$secNum}-{$m}\">{$role}{$modelBadge}</h3>\n{$renderedMd}\n";
            }

            $secHtml .= "</section>\n";
            $bodySections[] = $secHtml;
            $tocItems[] = "<li><a href=\"#s{$secNum}\"><span class=\"num\">{$numeral}.</span> <span class=\"label\">" . htmlspecialchars($secName, ENT_QUOTES) . "</span></a><ul>" . implode('', $subLinks) . "</ul></li>";
        }

        $quickSpec = htmlspecialchars($analysis['quick_think_provider'] . ' / ' . $analysis['quick_think_model'], ENT_QUOTES);
        $deepSpec  = htmlspecialchars($analysis['deep_think_provider'] . ' / ' . $analysis['deep_think_model'], ENT_QUOTES);
        $priceStr  = $analysis['market_price_at_analysis'] !== null
            ? htmlspecialchars((string)$analysis['market_price_at_analysis'] . ' ' . ($analysis['currency'] ?? 'USD'), ENT_QUOTES)
            : 'N/A';
        $entryStr  = $analysis['entry_price'] !== null ? htmlspecialchars((string)$analysis['entry_price'], ENT_QUOTES) : 'N/A';
        $stopStr   = $analysis['stop_loss'] !== null ? htmlspecialchars((string)$analysis['stop_loss'], ENT_QUOTES) : 'N/A';
        $targetStr = $analysis['price_target'] !== null ? htmlspecialchars((string)$analysis['price_target'], ENT_QUOTES) : 'N/A';

        $printScript = $autoPrintPdf ? "<script>window.addEventListener('load', function(){ setTimeout(function(){ window.print(); }, 350); });</script>" : '';

        return <<<HTML
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{$ticker} ({$date}) — {$ratingEsc} | TradingAgents AI Report</title>
<style>
:root {
  --paper: #fbfbfa; --ink: #1c2126; --muted: #5d6670; --rule: #e2e5e8; --wash: #f2f4f5;
  --accent: #087a59; --up: #087a59; --down: #b4372f; --level: #5d6670; --edge: #d3d8dc; --mark: #878f97;
  --serif: Charter, "Bitstream Charter", "Sitka Text", Cambria, Georgia, serif;
  --sans: system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  color-scheme: light;
}
* { box-sizing: border-box; }
body { margin: 0; background: var(--paper); color: var(--ink); font: 16.5px/1.65 var(--serif); }
.page { max-width: 50rem; margin: 0 auto; padding: 3rem 1.5rem 5rem; }
.masthead { padding-bottom: 1.75rem; border-bottom: 1px solid var(--rule); }
.masthead .top-bar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.75rem; }
.masthead .logo svg { height: 2rem; width: auto; color: var(--ink); }
.print-btn { font: 500 0.82rem/1.4 var(--sans); padding: 0.45rem 0.9rem; border-radius: 6px; border: 1px solid var(--edge); background: var(--wash); color: var(--ink); cursor: pointer; text-decoration: none; }
.print-btn:hover { border-color: var(--accent); color: var(--accent); }
.masthead h1 { margin: 0; font: 700 2.4rem/1.15 var(--sans); letter-spacing: -0.02em; display: flex; flex-wrap: wrap; align-items: baseline; gap: 0.3em 0.5em; }
.rating { padding: 0.1em 0.45em; border-radius: 6px; font-size: 0.7em; font-weight: 600; }
.rating.up { color: var(--up); background: rgba(16, 185, 129, 0.12); }
.rating.down { color: var(--down); background: rgba(244, 63, 94, 0.12); }
.rating.level, .rating.review { color: var(--level); background: var(--wash); }
.masthead .date { margin: 0.5rem 0 1.25rem; font: 0.95rem/1.4 var(--sans); color: var(--muted); }
.run { margin: 0; display: grid; grid-template-columns: max-content 1fr; gap: 0.4rem 1.25rem; font: 0.84rem/1.5 var(--sans); }
.run > div { display: contents; }
.run dt { color: var(--muted); font-weight: 500; }
.run dd { margin: 0; }
.field { display: inline-block; margin: 0 0.2rem 0.15rem 0; padding: 0.05rem 0.45rem; border: 1px solid var(--edge); border-radius: 4px; background: var(--wash); font: 0.76rem/1.5 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; color: var(--ink); }
.contents { margin: 2rem 0 0; padding: 1rem 1.25rem; background: var(--wash); border-radius: 8px; font: 0.88rem/1.5 var(--sans); }
.contents ul { margin: 0; padding: 0; list-style: none; }
.contents > ul > li { margin: 0 0 0.5rem; font-weight: 600; }
.contents ul ul { margin-top: 0.2rem; padding-left: 1.5rem; font-weight: 400; font-size: 0.83rem; }
.contents a { color: var(--ink); text-decoration: none; }
.contents a:hover { color: var(--accent); text-decoration: underline; }
main h2 { margin: 3.5rem 0 0.5rem; padding-top: 1.25rem; border-top: 2px solid var(--ink); font: 700 1.45rem/1.3 var(--sans); }
main h3 { margin: 2.25rem 0 0.75rem; padding-top: 1rem; border-top: 1px solid var(--rule); font: 600 1.12rem/1.35 var(--sans); color: var(--accent); display: flex; flex-wrap: wrap; align-items: center; gap: 0.5rem; }
main h4, main h5 { margin: 1.4rem 0 0.4rem; font: 600 0.98rem/1.4 var(--sans); }
main p, main ul, main ol { margin: 0 0 1rem; }
main blockquote { margin: 1rem 0; padding: 0.2rem 0 0.2rem 1rem; border-left: 3px solid var(--accent); color: var(--muted); }
.table-wrap { overflow-x: auto; margin: 1rem 0 1.5rem; }
table { border-collapse: collapse; width: 100%; font: 0.84rem/1.45 var(--sans); }
th, td { padding: 0.45rem 0.65rem; text-align: left; border-bottom: 1px solid var(--rule); }
th { font-weight: 600; background: var(--wash); border-bottom: 2px solid var(--edge); }
.credit { margin-top: 4rem; padding-top: 1.25rem; border-top: 1px solid var(--rule); color: var(--muted); font: 0.8rem/1.4 var(--sans); display: flex; justify-content: space-between; }
@media print {
  :root { --paper: #fff; --ink: #000; --muted: #444; --rule: #ccc; --wash: #f5f5f5; --edge: #ccc; }
  body { font-size: 10.5pt; }
  .page { max-width: none; padding: 0; }
  .print-btn { display: none !important; }
  main h2 { break-before: page; }
  main section:first-of-type h2 { break-before: auto; }
  table { break-inside: avoid; }
}
</style>
{$printScript}
</head>
<body>
<div class="page">
  <header class="masthead">
    <div class="top-bar">
      <div class="logo">
HTML
        . self::LOGO_SVG . <<<HTML
      </div>
      <button class="print-btn" onclick="window.print()">Print / Save as PDF</button>
    </div>
    <h1>
      <span>{$ticker}</span>
      <span style="font-weight:400;font-size:0.55em;color:var(--muted)">{$company}</span>
      <span class="rating {$tone}">{$ratingEsc}</span>
    </h1>
    <p class="date">Multi-Agent Financial Trading Analysis as of {$date} &bull; Generated by TradingAgents PHP 8.4</p>
    <dl class="run">
      <div><dt>Market Close &amp; Levels</dt><dd><span class="field">Close: {$priceStr}</span> <span class="field">Entry: {$entryStr}</span> <span class="field">Stop: {$stopStr}</span> <span class="field">Target: {$targetStr}</span></dd></div>
      <div><dt>Quick-Think LLM</dt><dd><span class="field">{$quickSpec}</span></dd></div>
      <div><dt>Deep-Think LLM</dt><dd><span class="field">{$deepSpec}</span></dd></div>
      <div><dt>Debate &amp; Telemetry</dt><dd><span class="field">Research Rounds: {$analysis['max_debate_rounds']}</span> <span class="field">Risk Rounds: {$analysis['max_risk_rounds']}</span> <span class="field">Tokens: {$analysis['total_tokens_used']}</span></dd></div>
    </dl>
  </header>
  <nav class="contents" aria-label="Table of Contents">
    <ul>
HTML
        . implode("\n", $tocItems) . <<<HTML
    </ul>
  </nav>
  <main>
HTML
        . implode("\n", $bodySections) . <<<HTML
  </main>
  <footer class="credit">
    <span>TradingAgents Multi-Agent AI Framework (PHP 8.4 + MySQL Edition)</span>
    <span>Reference: TauricResearch/TradingAgents</span>
  </footer>
</div>
</body>
</html>
HTML;
    }

    /**
     * Safe, zero-dependency CommonMark + GFM Pipe Table converter for agent reports.
     */
    public static function markdownToHtml(string $markdown): string
    {
        $lines = explode("\n", str_replace(["\r\n", "\r"], "\n", $markdown));
        $html  = [];
        $inTable = false;
        $inList  = false;
        $inCode  = false;

        foreach ($lines as $rawLine) {
            $line = rtrim($rawLine);

            if (str_starts_with(trim($line), '```')) {
                if ($inCode) {
                    $html[] = '</code></pre>';
                    $inCode = false;
                } else {
                    if ($inList) { $html[] = '</ul>'; $inList = false; }
                    if ($inTable) { $html[] = '</tbody></table></div>'; $inTable = false; }
                    $html[] = '<pre><code>';
                    $inCode = true;
                }
                continue;
            }

            if ($inCode) {
                $html[] = htmlspecialchars($line, ENT_QUOTES, 'UTF-8');
                continue;
            }

            // Pipe table handling
            if (str_starts_with(trim($line), '|') && str_ends_with(trim($line), '|')) {
                if ($inList) {
                    $html[] = '</ul>';
                    $inList = false;
                }
                $cells = array_map('trim', explode('|', trim(trim($line), '|')));
                // Check if separator row (e.g. | :--- | ---: |)
                $isSeparator = true;
                foreach ($cells as $c) {
                    if (!preg_match('/^:?-{2,}:?$/', $c)) {
                        $isSeparator = false;
                        break;
                    }
                }
                if ($isSeparator) {
                    continue;
                }
                if (!$inTable) {
                    $html[] = '<div class="table-wrap"><table><thead><tr>';
                    foreach ($cells as $c) {
                        $html[] = '<th>' . self::formatInline($c) . '</th>';
                    }
                    $html[] = '</tr></thead><tbody>';
                    $inTable = true;
                } else {
                    $html[] = '<tr>';
                    foreach ($cells as $c) {
                        $html[] = '<td>' . self::formatInline($c) . '</td>';
                    }
                    $html[] = '</tr>';
                }
                continue;
            } elseif ($inTable) {
                $html[] = '</tbody></table></div>';
                $inTable = false;
            }

            $trimmed = trim($line);
            if ($trimmed === '') {
                if ($inList) {
                    $html[] = '</ul>';
                    $inList = false;
                }
                continue;
            }

            // Headings (shifted to h4/h5 inside agent section)
            if (preg_match('/^(#{1,6})\s+(.*)$/', $trimmed, $m)) {
                if ($inList) { $html[] = '</ul>'; $inList = false; }
                $level = min(6, strlen($m[1]) + 2);
                $html[] = "<h{$level}>" . self::formatInline($m[2]) . "</h{$level}>";
                continue;
            }

            // Bullet list
            if (preg_match('/^[-*+]\s+(.*)$/', $trimmed, $m)) {
                if (!$inList) {
                    $html[] = '<ul>';
                    $inList = true;
                }
                $html[] = '<li>' . self::formatInline($m[1]) . '</li>';
                continue;
            }

            // Numbered list
            if (preg_match('/^\d+\.\s+(.*)$/', $trimmed, $m)) {
                if (!$inList) {
                    $html[] = '<ul>';
                    $inList = true;
                }
                $html[] = '<li>' . self::formatInline($m[1]) . '</li>';
                continue;
            }

            if ($inList) {
                $html[] = '</ul>';
                $inList = false;
            }

            if (str_starts_with($trimmed, '>')) {
                $html[] = '<blockquote>' . self::formatInline(ltrim(substr($trimmed, 1))) . '</blockquote>';
                continue;
            }

            $html[] = '<p>' . self::formatInline($trimmed) . '</p>';
        }

        if ($inCode) { $html[] = '</code></pre>'; }
        if ($inList) { $html[] = '</ul>'; }
        if ($inTable) { $html[] = '</tbody></table></div>'; }

        return implode("\n", $html);
    }

    private static function formatInline(string $text): string
    {
        $escaped = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
        // Bold **text**
        $escaped = (string)preg_replace('/\*\*(.+?)\*\*/', '<strong>$1</strong>', $escaped);
        // Inline code `code`
        $escaped = (string)preg_replace('/`([^`]+)`/', '<code>$1</code>', $escaped);
        // Safe Markdown links [label](https://...)
        $escaped = (string)preg_replace_callback(
            '/\[([^\]]+)\]\((https?:\/\/[^\s\)]+)\)/i',
            static fn(array $m) => '<a href="' . $m[2] . '" target="_blank" rel="noopener noreferrer">' . $m[1] . '</a>',
            $escaped
        );
        return $escaped;
    }
}
