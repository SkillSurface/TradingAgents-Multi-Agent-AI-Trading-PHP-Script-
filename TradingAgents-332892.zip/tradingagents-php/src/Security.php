<?php
/**
 * TradingAgents PHP 8.4 — Security, Cryptography (AES-256-GCM), CSRF & Auth Service
 *
 * Implements:
 * - AES-256-GCM authenticated encryption for API keys at rest
 * - CSRF token creation & verification
 * - Argon2id / Bcrypt password hashing & automatic rehash upgrade
 * - Brute-force login protection & account lockout
 * - Role-based access control (admin, analyst, viewer)
 */

declare(strict_types=1);

namespace TradingAgents;

use RuntimeException;

final class Security
{
    /**
     * Encrypts a sensitive string (such as an AI API Key) using AES-256-GCM.
     */
    public static function encrypt(string $plaintext): string
    {
        $masterHex = (string)Bootstrap::config('security.master_key', '');
        if (strlen($masterHex) < 64) {
            $masterHex = hash('sha256', $masterHex ?: 'ta_fallback_key_seed');
        }
        $key = hex2bin(substr($masterHex, 0, 64));
        $iv = random_bytes(12);
        $tag = '';
        $ciphertext = openssl_encrypt(
            $plaintext,
            'aes-256-gcm',
            $key,
            OPENSSL_RAW_DATA,
            $iv,
            $tag,
            '',
            16
        );
        if ($ciphertext === false) {
            throw new RuntimeException('AES-256-GCM encryption failed.');
        }
        return base64_encode($iv . $tag . $ciphertext);
    }

    /**
     * Decrypts an AES-256-GCM encrypted payload back into plaintext in memory.
     */
    public static function decrypt(string $encodedPayload): string
    {
        $raw = base64_decode($encodedPayload, true);
        if ($raw === false || strlen($raw) < 28) {
            throw new RuntimeException('Corrupted encrypted key payload.');
        }
        $masterHex = (string)Bootstrap::config('security.master_key', '');
        if (strlen($masterHex) < 64) {
            $masterHex = hash('sha256', $masterHex ?: 'ta_fallback_key_seed');
        }
        $key = hex2bin(substr($masterHex, 0, 64));
        $iv = substr($raw, 0, 12);
        $tag = substr($raw, 12, 16);
        $ciphertext = substr($raw, 28);

        $plaintext = openssl_decrypt(
            $ciphertext,
            'aes-256-gcm',
            $key,
            OPENSSL_RAW_DATA,
            $iv,
            $tag
        );
        if ($plaintext === false) {
            throw new RuntimeException('AES-256-GCM authentication tag verification failed.');
        }
        return $plaintext;
    }

    /**
     * Produces a safe masked preview of an API key (never exposes the middle secret).
     */
    public static function maskKey(string $key): string
    {
        $trimmed = trim($key);
        $len = strlen($trimmed);
        if ($len <= 10) {
            return substr($trimmed, 0, 2) . '••••' . substr($trimmed, -2);
        }
        return substr($trimmed, 0, 7) . '••••' . substr($trimmed, -4);
    }

    /**
     * Generates a cryptographically secure random key (for internal/webhook/custom API access).
     */
    public static function generateRandomKey(string $prefix = 'ta_sk_', int $bytes = 24): string
    {
        return $prefix . bin2hex(random_bytes($bytes));
    }

    /**
     * Generates or returns the active session CSRF token.
     */
    public static function csrfToken(): string
    {
        if (empty($_SESSION['ta_csrf_token']) || empty($_SESSION['ta_csrf_time'])
            || (time() - (int)$_SESSION['ta_csrf_time']) > (int)Bootstrap::config('security.csrf_token_ttl', 7200)
        ) {
            $_SESSION['ta_csrf_token'] = bin2hex(random_bytes(32));
            $_SESSION['ta_csrf_time']  = time();
        }
        return (string)$_SESSION['ta_csrf_token'];
    }

    /**
     * Verifies a submitted CSRF token (from POST body or X-CSRF-Token header).
     */
    public static function verifyCsrf(?string $token = null): bool
    {
        $token = $token ?? ($_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
        $sessionToken = $_SESSION['ta_csrf_token'] ?? '';
        if ($sessionToken === '' || $token === '') {
            return false;
        }
        return hash_equals((string)$sessionToken, (string)$token);
    }

    /**
     * Hashes a password with Argon2id (preferred on PHP 8.4) or Bcrypt.
     */
    public static function hashPassword(string $password): string
    {
        $algo = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
        return password_hash($password, $algo);
    }

    /**
     * Authenticates a user by username or email with brute-force lockout protection.
     */
    public static function login(string $identifier, string $password): array
    {
        $user = Database::fetchOne(
            "SELECT * FROM `users` WHERE (`username` = :id OR `email` = :id2) LIMIT 1",
            [':id' => trim($identifier), ':id2' => trim($identifier)]
        );

        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';

        if (!$user) {
            Logger::log('SECURITY', 'auth', "Failed login attempt for unknown identifier: {$identifier}", null, $ip);
            return ['ok' => false, 'error' => 'Invalid username/email or password.'];
        }

        if ((int)$user['is_active'] !== 1) {
            return ['ok' => false, 'error' => 'This user account has been disabled by an administrator.'];
        }

        if (!empty($user['locked_until']) && strtotime((string)$user['locked_until']) > time()) {
            $mins = ceil((strtotime((string)$user['locked_until']) - time()) / 60);
            return ['ok' => false, 'error' => "Account temporarily locked due to failed attempts. Try again in {$mins} min."];
        }

        if (!password_verify($password, (string)$user['password_hash'])) {
            $attempts = (int)$user['failed_login_attempts'] + 1;
            $lockedUntil = $attempts >= 5 ? gmdate('Y-m-d H:i:s', time() + 900) : null;
            Database::query(
                "UPDATE `users` SET `failed_login_attempts` = :a, `locked_until` = :l WHERE `id` = :id",
                [':a' => $attempts, ':l' => $lockedUntil, ':id' => $user['id']]
            );
            Logger::log('SECURITY', 'auth', "Invalid password for user {$user['username']} (attempt #{$attempts})", (int)$user['id'], $ip);
            return ['ok' => false, 'error' => 'Invalid username/email or password.'];
        }

        // Rehash if needed
        $algo = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
        if (password_needs_rehash((string)$user['password_hash'], $algo)) {
            $newHash = self::hashPassword($password);
            Database::query("UPDATE `users` SET `password_hash` = ? WHERE `id` = ?", [$newHash, $user['id']]);
        }

        // Reset failed attempts & record login
        Database::query(
            "UPDATE `users` SET `failed_login_attempts` = 0, `locked_until` = NULL, `last_login_at` = NOW(), `last_login_ip` = :ip WHERE `id` = :id",
            [':ip' => $ip, ':id' => $user['id']]
        );

        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }

        $_SESSION['ta_user'] = [
            'id'               => (int)$user['id'],
            'username'         => (string)$user['username'],
            'email'            => (string)$user['email'],
            'display_name'     => (string)($user['display_name'] ?: $user['username']),
            'role'             => (string)$user['role'],
            'theme_preference' => (string)$user['theme_preference'],
            'risk_profile'     => (string)$user['risk_profile'],
        ];

        Logger::log('INFO', 'auth', "User {$user['username']} signed in.", (int)$user['id'], $ip);
        return ['ok' => true, 'user' => $_SESSION['ta_user']];
    }

    public static function currentUser(): ?array
    {
        return $_SESSION['ta_user'] ?? null;
    }

    public static function requireAuth(): array
    {
        $user = self::currentUser();
        if (!$user) {
            if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) || str_contains($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json')) {
                http_response_code(401);
                header('Content-Type: application/json');
                echo json_encode(['ok' => false, 'error' => 'Authentication required.']);
                exit;
            }
            header('Location: login.php');
            exit;
        }
        return $user;
    }

    public static function requireAdmin(): array
    {
        $user = self::requireAuth();
        if (($user['role'] ?? '') !== 'admin') {
            http_response_code(403);
            die('403 Forbidden — Administrator privileges required.');
        }
        return $user;
    }

    public static function cleanTicker(string $ticker): string
    {
        $t = strtoupper(trim($ticker));
        // Allow letters, numbers, dots (.NS, .L), carets (^GSPC), hyphens (BTC-USD), equals (EURUSD=X)
        $t = preg_replace('/[^A-Z0-9.\^\-=]/', '', $t) ?? '';
        return substr($t, 0, 20);
    }
}
