<?php
/**
 * TradingAgents PHP 8.4 — Pure PHP Mathematical Technical Indicators Engine
 *
 * Computes all exact indicators used by the TradingAgents Market Analyst:
 * - Moving Averages: close_10_ema, close_50_sma, close_200_sma
 * - MACD Suite: macd (12,26 EMA diff), macds (9 EMA signal), macdh (MACD histogram)
 * - Momentum: rsi (14-period Wilder's RSI)
 * - Volatility: boll (20 SMA middle), boll_ub (+2σ), boll_lb (-2σ), atr (14-period Wilder's ATR)
 * - Volume: vwma (20-period Volume-Weighted Moving Average)
 * - Support/Resistance pivots, 52-week range, and Verified Market Snapshot
 */

declare(strict_types=1);

namespace TradingAgents;

final class TechnicalIndicators
{
    /**
     * Computes all technical indicators across an array of daily OHLCV bars.
     *
     * @param array<int, array{date: string, open: float, high: float, low: float, close: float, volume: float}> $bars
     * @return array{latest: array, series: array, summary_markdown: string}
     */
    public static function computeAll(array $bars): array
    {
        $n = count($bars);
        if ($n === 0) {
            return ['latest' => [], 'series' => [], 'summary_markdown' => 'No OHLCV bars available.'];
        }

        $closes  = array_column($bars, 'close');
        $highs   = array_column($bars, 'high');
        $lows    = array_column($bars, 'low');
        $volumes = array_column($bars, 'volume');

        $sma20  = self::sma($closes, 20);
        $sma50  = self::sma($closes, 50);
        $sma200 = self::sma($closes, 200);
        $ema10  = self::ema($closes, 10);
        $ema12  = self::ema($closes, 12);
        $ema26  = self::ema($closes, 26);

        // MACD (12, 26, 9)
        $macdLine = [];
        for ($i = 0; $i < $n; $i++) {
            if ($ema12[$i] !== null && $ema26[$i] !== null) {
                $macdLine[$i] = $ema12[$i] - $ema26[$i];
            } else {
                $macdLine[$i] = null;
            }
        }
        $macdSignal = self::emaNullable($macdLine, 9);
        $macdHist   = [];
        for ($i = 0; $i < $n; $i++) {
            $macdHist[$i] = ($macdLine[$i] !== null && $macdSignal[$i] !== null)
                ? ($macdLine[$i] - $macdSignal[$i])
                : null;
        }

        // Wilder's 14-period RSI
        $rsi14 = self::rsi($closes, 14);

        // Bollinger Bands (20, 2.0)
        [$bollMid, $bollUpper, $bollLower] = self::bollinger($closes, 20, 2.0);

        // Wilder's 14-period ATR
        $atr14 = self::atr($highs, $lows, $closes, 14);

        // 20-period Volume-Weighted Moving Average (VWMA)
        $vwma20 = self::vwma($closes, $volumes, 20);

        $series = [];
        for ($i = 0; $i < $n; $i++) {
            $series[$i] = [
                'date'          => $bars[$i]['date'],
                'open'          => round((float)$bars[$i]['open'], 4),
                'high'          => round((float)$bars[$i]['high'], 4),
                'low'           => round((float)$bars[$i]['low'], 4),
                'close'         => round((float)$bars[$i]['close'], 4),
                'volume'        => (int)$bars[$i]['volume'],
                'close_10_ema'  => $ema10[$i] !== null ? round($ema10[$i], 4) : null,
                'close_50_sma'  => $sma50[$i] !== null ? round($sma50[$i], 4) : null,
                'close_200_sma' => $sma200[$i] !== null ? round($sma200[$i], 4) : null,
                'macd'          => $macdLine[$i] !== null ? round($macdLine[$i], 4) : null,
                'macds'         => $macdSignal[$i] !== null ? round($macdSignal[$i], 4) : null,
                'macdh'         => $macdHist[$i] !== null ? round($macdHist[$i], 4) : null,
                'rsi'           => $rsi14[$i] !== null ? round($rsi14[$i], 2) : null,
                'boll'          => $bollMid[$i] !== null ? round($bollMid[$i], 4) : null,
                'boll_ub'       => $bollUpper[$i] !== null ? round($bollUpper[$i], 4) : null,
                'boll_lb'       => $bollLower[$i] !== null ? round($bollLower[$i], 4) : null,
                'atr'           => $atr14[$i] !== null ? round($atr14[$i], 4) : null,
                'vwma'          => $vwma20[$i] !== null ? round($vwma20[$i], 4) : null,
            ];
        }

        $latest = $series[$n - 1];
        $prev   = $n >= 2 ? $series[$n - 2] : $latest;

        // Compute 20-day support/resistance and 52-week high/low
        $recent20Slice = array_slice($bars, max(0, $n - 20));
        $support20     = min(array_column($recent20Slice, 'low'));
        $resistance20  = max(array_column($recent20Slice, 'high'));

        $yearSlice = array_slice($bars, max(0, $n - 252));
        $high52w   = max(array_column($yearSlice, 'high'));
        $low52w    = min(array_column($yearSlice, 'low'));

        $dayChangePct = ($prev['close'] > 0)
            ? round((($latest['close'] - $prev['close']) / $prev['close']) * 100, 2)
            : 0.0;

        $latest['day_change_pct'] = $dayChangePct;
        $latest['support_20d']    = round((float)$support20, 4);
        $latest['resistance_20d'] = round((float)$resistance20, 4);
        $latest['high_52w']       = round((float)$high52w, 4);
        $latest['low_52w']        = round((float)$low52w, 4);

        // Build verified markdown table for the Market Analyst prompt
        $mdLines = [
            "### Verified Market Snapshot & Technical Indicators (As of {$latest['date']})",
            "- **Latest Close**: {$latest['close']} ({$dayChangePct}% vs prior close {$prev['close']})",
            "- **Day Range**: {$latest['low']} – {$latest['high']} | **Volume**: " . number_format($latest['volume']),
            "- **20-Day Support / Resistance**: Support {$latest['support_20d']} / Resistance {$latest['resistance_20d']}",
            "- **52-Week Range**: {$latest['low_52w']} – {$latest['high_52w']}",
            "",
            "| Indicator Code | Indicator Name | Latest Value | Signal / Interpretation |",
            "| :--- | :--- | :--- | :--- |",
            "| `close_10_ema` | 10-Day EMA | " . ($latest['close_10_ema'] ?? 'N/A') . " | " . self::trendSignal($latest['close'], $latest['close_10_ema']) . " |",
            "| `close_50_sma` | 50-Day SMA | " . ($latest['close_50_sma'] ?? 'N/A') . " | " . self::trendSignal($latest['close'], $latest['close_50_sma']) . " |",
            "| `close_200_sma` | 200-Day SMA | " . ($latest['close_200_sma'] ?? 'N/A') . " | " . self::trendSignal($latest['close'], $latest['close_200_sma']) . " |",
            "| `rsi` | 14-Day Wilder RSI | " . ($latest['rsi'] ?? 'N/A') . " | " . self::rsiSignal($latest['rsi']) . " |",
            "| `macd` | MACD Line (12,26) | " . ($latest['macd'] ?? 'N/A') . " | " . (($latest['macdh'] ?? 0) >= 0 ? 'Bullish Momentum' : 'Bearish Momentum') . " |",
            "| `macds` | MACD Signal (9) | " . ($latest['macds'] ?? 'N/A') . " | Signal Line |",
            "| `macdh` | MACD Histogram | " . ($latest['macdh'] ?? 'N/A') . " | " . (($latest['macdh'] ?? 0) >= 0 ? 'Positive Histogram' : 'Negative Histogram') . " |",
            "| `boll_ub` | Bollinger Upper (20,2σ) | " . ($latest['boll_ub'] ?? 'N/A') . " | Upper Volatility Band |",
            "| `boll` | Bollinger Middle (20 SMA)| " . ($latest['boll'] ?? 'N/A') . " | Mean Reversion Baseline |",
            "| `boll_lb` | Bollinger Lower (20,2σ) | " . ($latest['boll_lb'] ?? 'N/A') . " | Lower Volatility Band |",
            "| `atr` | 14-Day ATR | " . ($latest['atr'] ?? 'N/A') . " | Implied 2x ATR Stop: " . ($latest['atr'] ? round($latest['close'] - 2 * $latest['atr'], 2) : 'N/A') . " |",
            "| `vwma` | 20-Day VWMA | " . ($latest['vwma'] ?? 'N/A') . " | " . self::trendSignal($latest['close'], $latest['vwma']) . " |",
            "",
            "#### Recent 15 Trading Sessions (OHLCV + Key Indicators)",
            "| Date | Open | High | Low | Close | Volume | 10 EMA | 50 SMA | RSI(14) | MACD Hist | ATR(14) |",
            "| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
        ];

        $recent15 = array_slice($series, max(0, $n - 15));
        foreach (array_reverse($recent15) as $r) {
            $mdLines[] = sprintf(
                "| %s | %s | %s | %s | **%s** | %s | %s | %s | %s | %s | %s |",
                $r['date'],
                $r['open'],
                $r['high'],
                $r['low'],
                $r['close'],
                number_format($r['volume']),
                $r['close_10_ema'] ?? '-',
                $r['close_50_sma'] ?? '-',
                $r['rsi'] ?? '-',
                $r['macdh'] ?? '-',
                $r['atr'] ?? '-'
            );
        }

        return [
            'latest'           => $latest,
            'series'           => $series,
            'summary_markdown' => implode("\n", $mdLines),
        ];
    }

    private static function trendSignal(float $close, ?float $ma): string
    {
        if ($ma === null || $ma <= 0) {
            return 'Insufficient history';
        }
        $diffPct = round((($close - $ma) / $ma) * 100, 2);
        return $close >= $ma ? "Price Above (+{$diffPct}%)" : "Price Below ({$diffPct}%)";
    }

    private static function rsiSignal(?float $rsi): string
    {
        if ($rsi === null) {
            return 'N/A';
        }
        if ($rsi >= 70.0) {
            return 'Overbought (≥70)';
        }
        if ($rsi <= 30.0) {
            return 'Oversold (≤30)';
        }
        if ($rsi >= 55.0) {
            return 'Bullish Momentum';
        }
        if ($rsi <= 45.0) {
            return 'Bearish Momentum';
        }
        return 'Neutral Range';
    }

    public static function sma(array $values, int $period): array
    {
        $n = count($values);
        $out = array_fill(0, $n, null);
        if ($period <= 0 || $n < $period) {
            return $out;
        }
        $sum = 0.0;
        for ($i = 0; $i < $n; $i++) {
            $sum += (float)$values[$i];
            if ($i >= $period) {
                $sum -= (float)$values[$i - $period];
            }
            if ($i >= $period - 1) {
                $out[$i] = $sum / $period;
            }
        }
        return $out;
    }

    public static function ema(array $values, int $period): array
    {
        $n = count($values);
        $out = array_fill(0, $n, null);
        if ($period <= 0 || $n === 0) {
            return $out;
        }
        $k = 2.0 / ($period + 1.0);
        $ema = (float)$values[0];
        $out[0] = $ema;
        for ($i = 1; $i < $n; $i++) {
            $ema = ((float)$values[$i] * $k) + ($ema * (1.0 - $k));
            $out[$i] = $ema;
        }
        return $out;
    }

    private static function emaNullable(array $values, int $period): array
    {
        $n = count($values);
        $out = array_fill(0, $n, null);
        $k = 2.0 / ($period + 1.0);
        $ema = null;
        for ($i = 0; $i < $n; $i++) {
            if ($values[$i] === null) {
                continue;
            }
            if ($ema === null) {
                $ema = (float)$values[$i];
            } else {
                $ema = ((float)$values[$i] * $k) + ($ema * (1.0 - $k));
            }
            $out[$i] = $ema;
        }
        return $out;
    }

    public static function rsi(array $closes, int $period = 14): array
    {
        $n = count($closes);
        $out = array_fill(0, $n, null);
        if ($n <= $period) {
            return $out;
        }

        $gainSum = 0.0;
        $lossSum = 0.0;
        for ($i = 1; $i <= $period; $i++) {
            $change = (float)$closes[$i] - (float)$closes[$i - 1];
            if ($change >= 0) {
                $gainSum += $change;
            } else {
                $lossSum += abs($change);
            }
        }

        $avgGain = $gainSum / $period;
        $avgLoss = $lossSum / $period;
        $out[$period] = ($avgLoss == 0.0) ? 100.0 : (100.0 - (100.0 / (1.0 + ($avgGain / $avgLoss))));

        for ($i = $period + 1; $i < $n; $i++) {
            $change = (float)$closes[$i] - (float)$closes[$i - 1];
            $gain = $change > 0 ? $change : 0.0;
            $loss = $change < 0 ? abs($change) : 0.0;
            $avgGain = (($avgGain * ($period - 1)) + $gain) / $period;
            $avgLoss = (($avgLoss * ($period - 1)) + $loss) / $period;
            $out[$i] = ($avgLoss == 0.0) ? 100.0 : (100.0 - (100.0 / (1.0 + ($avgGain / $avgLoss))));
        }

        return $out;
    }

    public static function bollinger(array $closes, int $period = 20, float $mult = 2.0): array
    {
        $n = count($closes);
        $mid = self::sma($closes, $period);
        $upper = array_fill(0, $n, null);
        $lower = array_fill(0, $n, null);

        for ($i = $period - 1; $i < $n; $i++) {
            $mean = $mid[$i];
            if ($mean === null) {
                continue;
            }
            $variance = 0.0;
            for ($j = $i - $period + 1; $j <= $i; $j++) {
                $diff = (float)$closes[$j] - $mean;
                $variance += $diff * $diff;
            }
            $stdDev = sqrt($variance / $period);
            $upper[$i] = $mean + ($mult * $stdDev);
            $lower[$i] = $mean - ($mult * $stdDev);
        }

        return [$mid, $upper, $lower];
    }

    public static function atr(array $highs, array $lows, array $closes, int $period = 14): array
    {
        $n = count($closes);
        $out = array_fill(0, $n, null);
        if ($n === 0) {
            return $out;
        }

        $tr = [];
        $tr[0] = (float)$highs[0] - (float)$lows[0];
        for ($i = 1; $i < $n; $i++) {
            $hl = (float)$highs[$i] - (float)$lows[$i];
            $hc = abs((float)$highs[$i] - (float)$closes[$i - 1]);
            $lc = abs((float)$lows[$i] - (float)$closes[$i - 1]);
            $tr[$i] = max($hl, $hc, $lc);
        }

        if ($n < $period) {
            return $out;
        }

        $atr = array_sum(array_slice($tr, 0, $period)) / $period;
        $out[$period - 1] = $atr;
        for ($i = $period; $i < $n; $i++) {
            $atr = (($atr * ($period - 1)) + $tr[$i]) / $period;
            $out[$i] = $atr;
        }
        return $out;
    }

    public static function vwma(array $closes, array $volumes, int $period = 20): array
    {
        $n = count($closes);
        $out = array_fill(0, $n, null);
        if ($n < $period) {
            return $out;
        }
        for ($i = $period - 1; $i < $n; $i++) {
            $pvSum = 0.0;
            $vSum  = 0.0;
            for ($j = $i - $period + 1; $j <= $i; $j++) {
                $v = (float)$volumes[$j];
                $pvSum += (float)$closes[$j] * $v;
                $vSum  += $v;
            }
            $out[$i] = $vSum > 0 ? ($pvSum / $vSum) : (float)$closes[$i];
        }
        return $out;
    }
}
